/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dominosOrder;

import java.awt.Color;
import java.awt.Image;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author victor
 */

public class DominosOrder extends javax.swing.JFrame {

    /**
     * Creates new form DominosOrder
     */
    public DominosOrder() {
        initComponents();
        _pizzaField.setVisible(false);
        _pizzaAddLabel.setVisible(false);
        _pizzaMinusLabel.setVisible(false);
        _pizzaNumberLabel.setVisible(false);
        _dishLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dish.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pizza.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        
        _pizzaLabel.setVisible(false);
        _deleteLabel.setVisible(false);
        _deleteTittleLabel.setVisible(false);
        
        _tickTomatoLabel.setVisible(false);
        _tickBarbacueLabel.setVisible(false);
        _tickCreamLabel.setVisible(false);
        _tickBourbonLabel.setVisible(false);
        _tickOliveLabel.setVisible(false);
        _tickAnchovyLabel.setVisible(false);
        _tickTunaLabel.setVisible(false);
        _tickBaconLabel.setVisible(false);
        _tickOnionLabel.setVisible(false);
        _tickMushroomLabel.setVisible(false);
        _tickYorkLabel.setVisible(false);
        _tickHamLabel.setVisible(false);
        _tickCornLabel.setVisible(false);
        _tickPepperoniLabel.setVisible(false);
        _tickPepperLabel.setVisible(false);
        _tickPineappleLabel.setVisible(false);
        _tickChickenLabel.setVisible(false);
        _tickBeefLabel.setVisible(false);
        _tickTomatoeLabel.setVisible(false);
        _tickCaramelLabel.setVisible(false);
        _tickFinizzimaLabel.setVisible(false);
        _tickOriginalLabel.setVisible(false);
        _tickPanLabel.setVisible(false);
        _tickMediumLabel.setVisible(false);
        _tickFamiliarLabel.setVisible(false);
        
        _previousLabel.setVisible(false);
        _nextLabel.setVisible(false);
        
        
        _cornsLabel.setVisible(false);
        _olivesLabel.setVisible(false);
        _pineapplesLabel.setVisible(false);
        _caramelsLabel.setVisible(false);
        _onionsLabel.setVisible(false);
        _peppersLabel.setVisible(false);
        _mushroomsLabel.setVisible(false);
        _tunasLabel.setVisible(false);
        _anchoviesLabel.setVisible(false);
        _beefsLabel.setVisible(false);
        _chickensLabel.setVisible(false);
        _yorksLabel.setVisible(false);
        _hamsLabel.setVisible(false);
        _baconsLabel.setVisible(false);
        _pepperonisLabel.setVisible(false);
        _tomatoesLabel.setVisible(false);
        
        
        
        _sodaTrashLabel.setVisible(false);
        _orderItemsLabel.setText("0");
        _itemsPanel.setVisible(false);
        _confirmPanel.setVisible(false);
        _confirmLabel.setVisible(false);
        _backLabel.setVisible(false);
        _pepsiSquirtLabel.setVisible(false);
        _lightSquirtLabel.setVisible(false);
        _orangeSquirtLabel.setVisible(false);
        _lemonSquirtLabel.setVisible(false);
        _zeroSquirtLabel.setVisible(false);
        _strawberryNumberLabel.setText("0");
        _doughNumberLabel.setText("0");
        _chunkyNumberLabel.setText("0");
        _chocolateNumberLabel.setText("0");
        _caramelNumberLabel.setText("0");
        _appleNumberLabel.setText("0");
        _cookiesNumberLabel.setText("0");
        _vulcanoNumberLabel.setText("0");
        _brownieNumberLabel.setText("0");
        _trufflesNumberLabel.setText("0");
        _strawberryTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _doughTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _chunkyTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _chocolateTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _caramelTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _appleTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _cookiesTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _vulcanoTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _brownieTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _trufflesTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _chickenNumberLabel.setText("0");
        _wingsNumberLabel.setText("0");
        _cheeseBreadNumberLabel.setText("0");
        _breadNumberLabel.setText("0");
        _kickersNumberLabel.setText("0");
        _wingNumberLabel.setText("0");
        _strippersNumberLabel.setText("0");
        _potatoesNumberLabel.setText("0");
        _chickenTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _wingsTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _cheeseBreadTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _breadTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _kickersTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _wingTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _strippersTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _potatoesTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _waterNumberLabel.setText("0");
        _redBullNumberLabel.setText("0");
        _waterTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _redBullTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
        _sodaMinusLabel.setVisible(false);
        _sodaNumberLabel.setVisible(false);
        _sodaAddLabel.setVisible(false);
        _sodaNumberLabel.setText("0");
        _pepsiNumberLabel.setText("0");
        _lightNumberLabel.setText("0");
        _orangeNumberLabel.setText("0");
        _lemonNumberLabel.setText("0");
        _zeroNumberLabel.setText("0");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        _parentPanel = new javax.swing.JPanel();
        _startCardPanel = new javax.swing.JPanel();
        _logoLabel = new javax.swing.JLabel();
        _startLabel = new javax.swing.JLabel();
        _headCard = new javax.swing.JPanel();
        _navigatorPanel = new javax.swing.JPanel();
        _dominosLabel = new javax.swing.JLabel();
        _waiterPanel = new javax.swing.JPanel();
        _waiterLabel = new javax.swing.JLabel();
        _waiterIconLabel = new javax.swing.JLabel();
        _orderPanel = new javax.swing.JPanel();
        _orderLabel = new javax.swing.JLabel();
        _orderIconLabel = new javax.swing.JLabel();
        _orderItemsLabel = new javax.swing.JLabel();
        _backLabel = new javax.swing.JLabel();
        _itemsPanel = new javax.swing.JPanel();
        _itemNumberLabel = new javax.swing.JLabel();
        _itemNameLabel = new javax.swing.JLabel();
        _itemPriceLabel = new javax.swing.JLabel();
        _tittleLabel = new javax.swing.JLabel();
        _confirmPanel = new javax.swing.JPanel();
        _confirmLabel = new javax.swing.JLabel();
        _cardsPanel = new javax.swing.JPanel();
        _menuCard = new javax.swing.JPanel();
        _pizzasIconLabel = new javax.swing.JLabel();
        _drinksIconLabel = new javax.swing.JLabel();
        _snacksIconLabel = new javax.swing.JLabel();
        _dessertsIconLabel = new javax.swing.JLabel();
        _pizzasLabel = new javax.swing.JLabel();
        _drinksLabel = new javax.swing.JLabel();
        _snacksLabel = new javax.swing.JLabel();
        _dessertsLabel = new javax.swing.JLabel();
        _pizzasCard = new javax.swing.JPanel();
        _draggableLabel = new javax.swing.JLabel();
        _pizzaMinusLabel = new javax.swing.JLabel();
        _pizzaNumberLabel = new javax.swing.JLabel();
        _pizzaAddLabel = new javax.swing.JLabel();
        _pizzaField = new javax.swing.JTextField();
        _tickMediumLabel = new javax.swing.JLabel();
        _tickFamiliarLabel = new javax.swing.JLabel();
        _mediumLabel = new javax.swing.JLabel();
        _familiarLabel = new javax.swing.JLabel();
        _familiarTittleLabel = new javax.swing.JLabel();
        _mediumTittleLabel = new javax.swing.JLabel();
        _deleteLabel = new javax.swing.JLabel();
        _saveLabel = new javax.swing.JLabel();
        _saveTittleLabel = new javax.swing.JLabel();
        _deleteTittleLabel = new javax.swing.JLabel();
        _tickCreamLabel = new javax.swing.JLabel();
        _tickBarbacueLabel = new javax.swing.JLabel();
        _tickTomatoLabel = new javax.swing.JLabel();
        _tickBourbonLabel = new javax.swing.JLabel();
        _tickFinizzimaLabel = new javax.swing.JLabel();
        _tickOriginalLabel = new javax.swing.JLabel();
        _tickPanLabel = new javax.swing.JLabel();
        _tickOliveLabel = new javax.swing.JLabel();
        _tickAnchovyLabel = new javax.swing.JLabel();
        _tickTunaLabel = new javax.swing.JLabel();
        _tickBaconLabel = new javax.swing.JLabel();
        _tickOnionLabel = new javax.swing.JLabel();
        _tickMushroomLabel = new javax.swing.JLabel();
        _tickYorkLabel = new javax.swing.JLabel();
        _tickHamLabel = new javax.swing.JLabel();
        _tickCornLabel = new javax.swing.JLabel();
        _tickPepperoniLabel = new javax.swing.JLabel();
        _tickPepperLabel = new javax.swing.JLabel();
        _tickPineappleLabel = new javax.swing.JLabel();
        _tickChickenLabel = new javax.swing.JLabel();
        _tickBeefLabel = new javax.swing.JLabel();
        _tickTomatoeLabel = new javax.swing.JLabel();
        _tickCaramelLabel = new javax.swing.JLabel();
        _anchovyLabel = new javax.swing.JLabel();
        _beefLabel = new javax.swing.JLabel();
        _pizzaChickenLabel = new javax.swing.JLabel();
        _oliveLabel = new javax.swing.JLabel();
        _pepperoniLabel = new javax.swing.JLabel();
        _cornLabel = new javax.swing.JLabel();
        _hamLabel = new javax.swing.JLabel();
        _baconLabel = new javax.swing.JLabel();
        _onionLabel = new javax.swing.JLabel();
        _mushroomLabel = new javax.swing.JLabel();
        _yorkLabel = new javax.swing.JLabel();
        _pineappleLabel = new javax.swing.JLabel();
        _tunaLabel = new javax.swing.JLabel();
        _pepperLabel = new javax.swing.JLabel();
        _caramelPizzaLabel = new javax.swing.JLabel();
        _tomateLabel = new javax.swing.JLabel();
        _bourbonLabel = new javax.swing.JLabel();
        _panLabel = new javax.swing.JLabel();
        _barbacueLabel = new javax.swing.JLabel();
        _creamLabel = new javax.swing.JLabel();
        _barbacueTittleLabel = new javax.swing.JLabel();
        _tomatoTittleLabel = new javax.swing.JLabel();
        _creamTittleLabel = new javax.swing.JLabel();
        _bourbonTittleLabel = new javax.swing.JLabel();
        _tomatoLabel = new javax.swing.JLabel();
        _finizzimaLabel = new javax.swing.JLabel();
        _originalLabel = new javax.swing.JLabel();
        _finizzimaTittleLabel = new javax.swing.JLabel();
        _originalTittleLabel = new javax.swing.JLabel();
        _panTittleLabel = new javax.swing.JLabel();
        _nextLabel = new javax.swing.JLabel();
        _previousLabel = new javax.swing.JLabel();
        _cornsLabel = new javax.swing.JLabel();
        _olivesLabel = new javax.swing.JLabel();
        _pineapplesLabel = new javax.swing.JLabel();
        _caramelsLabel = new javax.swing.JLabel();
        _onionsLabel = new javax.swing.JLabel();
        _peppersLabel = new javax.swing.JLabel();
        _mushroomsLabel = new javax.swing.JLabel();
        _tunasLabel = new javax.swing.JLabel();
        _anchoviesLabel = new javax.swing.JLabel();
        _beefsLabel = new javax.swing.JLabel();
        _chickensLabel = new javax.swing.JLabel();
        _yorksLabel = new javax.swing.JLabel();
        _hamsLabel = new javax.swing.JLabel();
        _baconsLabel = new javax.swing.JLabel();
        _pepperonisLabel = new javax.swing.JLabel();
        _tomatoesLabel = new javax.swing.JLabel();
        _pizzaDrag = new javax.swing.JLabel();
        _pizzaLabel = new javax.swing.JLabel();
        _dishLabel = new javax.swing.JLabel();
        _drinksCard = new javax.swing.JPanel();
        _containerPanel = new javax.swing.JPanel();
        _beverageLabel = new javax.swing.JLabel();
        _sodaLabel = new javax.swing.JLabel();
        _drinksCardsPanel = new javax.swing.JPanel();
        _tapCard = new javax.swing.JPanel();
        _sodaTrashLabel = new javax.swing.JLabel();
        _pepsiLabel = new javax.swing.JLabel();
        _lightLabel = new javax.swing.JLabel();
        _lemonLabel = new javax.swing.JLabel();
        _orangeLabel = new javax.swing.JLabel();
        _zeroLabel = new javax.swing.JLabel();
        _tap1 = new javax.swing.JLabel();
        _tap2 = new javax.swing.JLabel();
        _tap3 = new javax.swing.JLabel();
        _tap4 = new javax.swing.JLabel();
        _tap5 = new javax.swing.JLabel();
        _pepsiSquirtLabel = new javax.swing.JLabel();
        _lightSquirtLabel = new javax.swing.JLabel();
        _orangeSquirtLabel = new javax.swing.JLabel();
        _lemonSquirtLabel = new javax.swing.JLabel();
        _zeroSquirtLabel = new javax.swing.JLabel();
        _sodaCardboardLabel = new javax.swing.JLabel();
        _sodaMinusLabel = new javax.swing.JLabel();
        _sodaNumberLabel = new javax.swing.JLabel();
        _sodaAddLabel = new javax.swing.JLabel();
        _pepsiAddLabel = new javax.swing.JLabel();
        _pepsiNumberLabel = new javax.swing.JLabel();
        _pepsiMinusLabel = new javax.swing.JLabel();
        _lightMinusLabel = new javax.swing.JLabel();
        _lightNumberLabel = new javax.swing.JLabel();
        _lightAddLabel = new javax.swing.JLabel();
        _orangeMinusLabel = new javax.swing.JLabel();
        _orangeNumberLabel = new javax.swing.JLabel();
        _orangeAddLabel = new javax.swing.JLabel();
        _lemonMinusLabel = new javax.swing.JLabel();
        _lemonNumberLabel = new javax.swing.JLabel();
        _lemonAddLabel = new javax.swing.JLabel();
        _zeroMinusLabel = new javax.swing.JLabel();
        _zeroNumberLabel = new javax.swing.JLabel();
        _zeroAddLabel = new javax.swing.JLabel();
        _beverageCard = new javax.swing.JPanel();
        _waterTittleLabel = new javax.swing.JLabel();
        _redBullTittleLabel = new javax.swing.JLabel();
        _waterLabel = new javax.swing.JLabel();
        _waterNumberLabel = new javax.swing.JLabel();
        _waterAddLabel = new javax.swing.JLabel();
        _waterMinusLabel = new javax.swing.JLabel();
        _redBullLabel = new javax.swing.JLabel();
        _redBullNumberLabel = new javax.swing.JLabel();
        _redBullAddLabel = new javax.swing.JLabel();
        _redBullMinusLabel = new javax.swing.JLabel();
        _snacksCard = new javax.swing.JPanel();
        _potatoesLabel = new javax.swing.JLabel();
        _potatoesNumberLabel = new javax.swing.JLabel();
        _potatoesAddLabel = new javax.swing.JLabel();
        _potatoesMinusLabel = new javax.swing.JLabel();
        _chickenTittleLabel = new javax.swing.JLabel();
        _chickenLabel = new javax.swing.JLabel();
        _chickenNumberLabel = new javax.swing.JLabel();
        _chickenAddLabel = new javax.swing.JLabel();
        _chickenMinusLabel = new javax.swing.JLabel();
        _kickersLabel = new javax.swing.JLabel();
        _kickersNumberLabel = new javax.swing.JLabel();
        _kickersAddLabel = new javax.swing.JLabel();
        _kickersMinusLabel = new javax.swing.JLabel();
        _wingsLabel = new javax.swing.JLabel();
        _wingsNumberLabel = new javax.swing.JLabel();
        _wingsAddLabel = new javax.swing.JLabel();
        _wingsMinusLabel = new javax.swing.JLabel();
        _wingLabel = new javax.swing.JLabel();
        _wingNumberLabel = new javax.swing.JLabel();
        _wingAddLabel = new javax.swing.JLabel();
        _wingMinusLabel = new javax.swing.JLabel();
        _cheeseBreadLabel = new javax.swing.JLabel();
        _cheeseBreadNumberLabel = new javax.swing.JLabel();
        _cheeseBreadAddLabel = new javax.swing.JLabel();
        _cheeseBreadMinusLabel = new javax.swing.JLabel();
        _strippersLabel = new javax.swing.JLabel();
        _wingsTittleLabel = new javax.swing.JLabel();
        _breadTittleLabel = new javax.swing.JLabel();
        _cheeseBreadTittleLabel = new javax.swing.JLabel();
        _kickersTittleLabel = new javax.swing.JLabel();
        _wingTittleLabel = new javax.swing.JLabel();
        _strippersTittleLabel = new javax.swing.JLabel();
        _potatoesTittleLabel = new javax.swing.JLabel();
        _strippersNumberLabel = new javax.swing.JLabel();
        _strippersAddLabel = new javax.swing.JLabel();
        _strippersMinusLabel = new javax.swing.JLabel();
        _breadLabel = new javax.swing.JLabel();
        _breadNumberLabel = new javax.swing.JLabel();
        _breadAddLabel = new javax.swing.JLabel();
        _breadMinusLabel = new javax.swing.JLabel();
        _dessertsCard = new javax.swing.JPanel();
        _strawberryLabel = new javax.swing.JLabel();
        _strawberryNumberLabel = new javax.swing.JLabel();
        _strawberryAddLabel = new javax.swing.JLabel();
        _strawberryMinusLabel = new javax.swing.JLabel();
        _appleLabel = new javax.swing.JLabel();
        _appleNumberLabel = new javax.swing.JLabel();
        _appleAddLabel = new javax.swing.JLabel();
        _appleMinusLabel = new javax.swing.JLabel();
        _doughLabel = new javax.swing.JLabel();
        _doughNumberLabel = new javax.swing.JLabel();
        _doughAddLabel = new javax.swing.JLabel();
        _doughMinusLabel = new javax.swing.JLabel();
        _cookiesLabel = new javax.swing.JLabel();
        _cookiesNumberLabel = new javax.swing.JLabel();
        _cookiesAddLabel = new javax.swing.JLabel();
        _cookiesMinusLabel = new javax.swing.JLabel();
        _chunkyLabel = new javax.swing.JLabel();
        _chunkyNumberLabel = new javax.swing.JLabel();
        _chunkyAddLabel = new javax.swing.JLabel();
        _chunkyMinusLabel = new javax.swing.JLabel();
        _vulcanoLabel = new javax.swing.JLabel();
        _vulcanoNumberLabel = new javax.swing.JLabel();
        _vulcanoAddLabel = new javax.swing.JLabel();
        _vulcanoMinusLabel = new javax.swing.JLabel();
        _chocolateLabel = new javax.swing.JLabel();
        _chocolateNumberLabel = new javax.swing.JLabel();
        _chocolateAddLabel = new javax.swing.JLabel();
        _chocolateMinusLabel = new javax.swing.JLabel();
        _caramelLabel = new javax.swing.JLabel();
        _caramelNumberLabel = new javax.swing.JLabel();
        _caramelAddLabel = new javax.swing.JLabel();
        _caramelMinusLabel = new javax.swing.JLabel();
        _brownieLabel = new javax.swing.JLabel();
        _brownieNumberLabel = new javax.swing.JLabel();
        _brownieAddLabel = new javax.swing.JLabel();
        _brownieMinusLabel = new javax.swing.JLabel();
        _trufflesLabel = new javax.swing.JLabel();
        _trufflesNumberLabel = new javax.swing.JLabel();
        _trufflesAddLabel = new javax.swing.JLabel();
        _trufflesMinusLabel = new javax.swing.JLabel();
        _strawberryTittleLabel = new javax.swing.JLabel();
        _doughTittleLabel = new javax.swing.JLabel();
        _chocolateTittleLabel = new javax.swing.JLabel();
        _chunkyTittleLabel = new javax.swing.JLabel();
        _appleTittleLabel = new javax.swing.JLabel();
        _cookiesTittleLabel = new javax.swing.JLabel();
        _vulcanoTittleLabel = new javax.swing.JLabel();
        _brownieTittleLabel = new javax.swing.JLabel();
        _trufflesTittleLabel = new javax.swing.JLabel();
        _caramelTittleLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        _parentPanel.setLayout(new java.awt.CardLayout());

        _startCardPanel.setBackground(new java.awt.Color(0, 98, 183));

        _logoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _logoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/logo.png"))); // NOI18N

        _startLabel.setFont(new java.awt.Font("FreeSans", 1, 60)); // NOI18N
        _startLabel.setForeground(java.awt.Color.white);
        _startLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _startLabel.setText("Comenzar pedido");
        _startLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _startLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout _startCardPanelLayout = new javax.swing.GroupLayout(_startCardPanel);
        _startCardPanel.setLayout(_startCardPanelLayout);
        _startCardPanelLayout.setHorizontalGroup(
            _startCardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_startCardPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(_logoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(_startCardPanelLayout.createSequentialGroup()
                .addGap(305, 305, 305)
                .addComponent(_startLabel)
                .addContainerGap(304, Short.MAX_VALUE))
        );
        _startCardPanelLayout.setVerticalGroup(
            _startCardPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_startCardPanelLayout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(_logoLabel)
                .addGap(36, 36, 36)
                .addComponent(_startLabel)
                .addContainerGap(156, Short.MAX_VALUE))
        );

        _parentPanel.add(_startCardPanel, "card2");

        _headCard.setBackground(new java.awt.Color(0, 98, 183));
        _headCard.setLayout(null);

        _navigatorPanel.setBackground(java.awt.Color.white);

        _dominosLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _dominosLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dominos.png"))); // NOI18N

        _waiterPanel.setBackground(java.awt.Color.white);
        _waiterPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _waiterPanelMouseClicked(evt);
            }
        });

        _waiterLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _waiterLabel.setForeground(new java.awt.Color(0, 98, 183));
        _waiterLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _waiterLabel.setText("¡CAMARERO!");

        _waiterIconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _waiterIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/waiter.png"))); // NOI18N

        javax.swing.GroupLayout _waiterPanelLayout = new javax.swing.GroupLayout(_waiterPanel);
        _waiterPanel.setLayout(_waiterPanelLayout);
        _waiterPanelLayout.setHorizontalGroup(
            _waiterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_waiterPanelLayout.createSequentialGroup()
                .addGap(0, 12, Short.MAX_VALUE)
                .addGroup(_waiterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_waiterLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_waiterIconLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        _waiterPanelLayout.setVerticalGroup(
            _waiterPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_waiterPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(_waiterLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(_waiterIconLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        _orderPanel.setBackground(new java.awt.Color(223, 30, 60));
        _orderPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _orderPanelMouseClicked(evt);
            }
        });
        _orderPanel.setLayout(null);

        _orderLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _orderLabel.setForeground(java.awt.Color.white);
        _orderLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orderLabel.setText("PEDIDO");
        _orderPanel.add(_orderLabel);
        _orderLabel.setBounds(0, 10, 140, 20);

        _orderIconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orderIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bag.png"))); // NOI18N
        _orderPanel.add(_orderIconLabel);
        _orderIconLabel.setBounds(0, 30, 140, 50);

        _orderItemsLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _orderItemsLabel.setForeground(java.awt.Color.white);
        _orderItemsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orderItemsLabel.setText("18");
        _orderPanel.add(_orderItemsLabel);
        _orderItemsLabel.setBounds(0, 50, 140, 17);

        _backLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _backLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/back.png"))); // NOI18N
        _backLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _backLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout _navigatorPanelLayout = new javax.swing.GroupLayout(_navigatorPanel);
        _navigatorPanel.setLayout(_navigatorPanelLayout);
        _navigatorPanelLayout.setHorizontalGroup(
            _navigatorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_navigatorPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(_backLabel)
                .addGap(376, 376, 376)
                .addComponent(_dominosLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 154, Short.MAX_VALUE)
                .addComponent(_waiterPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_orderPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        _navigatorPanelLayout.setVerticalGroup(
            _navigatorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(_orderPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(_waiterPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
            .addGroup(_navigatorPanelLayout.createSequentialGroup()
                .addGroup(_navigatorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, _navigatorPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(_backLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, _navigatorPanelLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(_dominosLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        _headCard.add(_navigatorPanel);
        _navigatorPanel.setBounds(0, 0, 1120, 81);

        _itemsPanel.setBackground(new java.awt.Color(223, 30, 60));
        _itemsPanel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _itemsPanelMouseDragged(evt);
            }
        });
        _itemsPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _itemsPanelMouseClicked(evt);
            }
        });

        _itemNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 14)); // NOI18N
        _itemNumberLabel.setForeground(java.awt.Color.white);
        _itemNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _itemNumberLabel.setText("2 ");
        _itemNumberLabel.setAlignmentX(0.5F);
        _itemNumberLabel.setPreferredSize(new java.awt.Dimension(20, 18));
        _itemsPanel.add(_itemNumberLabel);

        _itemNameLabel.setFont(new java.awt.Font("FreeSans", 0, 14)); // NOI18N
        _itemNameLabel.setForeground(java.awt.Color.white);
        _itemNameLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        _itemNameLabel.setText("Pizza Cuatro Quesos");
        _itemNameLabel.setAlignmentX(0.5F);
        _itemNameLabel.setPreferredSize(new java.awt.Dimension(180, 18));
        _itemsPanel.add(_itemNameLabel);

        _itemPriceLabel.setFont(new java.awt.Font("FreeSans", 1, 14)); // NOI18N
        _itemPriceLabel.setForeground(java.awt.Color.white);
        _itemPriceLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        _itemPriceLabel.setText("99.29 €");
        _itemPriceLabel.setAlignmentX(0.5F);
        _itemPriceLabel.setPreferredSize(new java.awt.Dimension(55, 18));
        _itemsPanel.add(_itemPriceLabel);

        _tittleLabel.setFont(new java.awt.Font("FreeSans", 1, 14)); // NOI18N
        _tittleLabel.setForeground(java.awt.Color.white);
        _tittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        _tittleLabel.setText("POSTRES");
        _tittleLabel.setAlignmentX(0.5F);
        _tittleLabel.setPreferredSize(new java.awt.Dimension(270, 18));
        _itemsPanel.add(_tittleLabel);

        _confirmPanel.setBackground(new java.awt.Color(150, 179, 48));
        _confirmPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _confirmPanelMouseClicked(evt);
            }
        });

        _confirmLabel.setFont(new java.awt.Font("FreeSans", 0, 24)); // NOI18N
        _confirmLabel.setForeground(java.awt.Color.white);
        _confirmLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _confirmLabel.setText("CONFIRMAR");

        javax.swing.GroupLayout _confirmPanelLayout = new javax.swing.GroupLayout(_confirmPanel);
        _confirmPanel.setLayout(_confirmPanelLayout);
        _confirmPanelLayout.setHorizontalGroup(
            _confirmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 280, Short.MAX_VALUE)
            .addGroup(_confirmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(_confirmPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(_confirmLabel)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        _confirmPanelLayout.setVerticalGroup(
            _confirmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 53, Short.MAX_VALUE)
            .addGroup(_confirmPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(_confirmPanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(_confirmLabel)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        _itemsPanel.add(_confirmPanel);

        _headCard.add(_itemsPanel);
        _itemsPanel.setBounds(840, 80, 280, 620);

        _cardsPanel.setBackground(new java.awt.Color(0, 98, 183));
        _cardsPanel.setLayout(new java.awt.CardLayout());

        _menuCard.setBackground(new java.awt.Color(0, 98, 183));
        _menuCard.setLayout(null);

        _pizzasIconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzasIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/extravaganzza.png"))); // NOI18N
        _pizzasIconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pizzasLabelMouseClicked(evt);
            }
        });
        _menuCard.add(_pizzasIconLabel);
        _pizzasIconLabel.setBounds(65, 189, 194, 192);

        _drinksIconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _drinksIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepsi.png"))); // NOI18N
        _drinksIconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _drinksMouseClicked(evt);
            }
        });
        _menuCard.add(_drinksIconLabel);
        _drinksIconLabel.setBounds(322, 189, 161, 192);

        _snacksIconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _snacksIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/snacks.png"))); // NOI18N
        _snacksIconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _snacksMouseClicked(evt);
            }
        });
        _menuCard.add(_snacksIconLabel);
        _snacksIconLabel.setBounds(546, 189, 254, 192);

        _dessertsIconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _dessertsIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/desserts.png"))); // NOI18N
        _dessertsIconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _dessertsMouseClicked(evt);
            }
        });
        _menuCard.add(_dessertsIconLabel);
        _dessertsIconLabel.setBounds(863, 189, 192, 192);

        _pizzasLabel.setFont(new java.awt.Font("FreeSans", 1, 36)); // NOI18N
        _pizzasLabel.setForeground(java.awt.Color.white);
        _pizzasLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzasLabel.setText("PIZZAS");
        _pizzasLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pizzasLabelMouseClicked(evt);
            }
        });
        _menuCard.add(_pizzasLabel);
        _pizzasLabel.setBounds(65, 387, 194, 44);

        _drinksLabel.setFont(new java.awt.Font("FreeSans", 1, 36)); // NOI18N
        _drinksLabel.setForeground(java.awt.Color.white);
        _drinksLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _drinksLabel.setText("BEBIDAS");
        _drinksLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _drinksMouseClicked(evt);
            }
        });
        _menuCard.add(_drinksLabel);
        _drinksLabel.setBounds(322, 387, 161, 44);

        _snacksLabel.setFont(new java.awt.Font("FreeSans", 1, 36)); // NOI18N
        _snacksLabel.setForeground(java.awt.Color.white);
        _snacksLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _snacksLabel.setText("ENTRANTES");
        _snacksLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _snacksMouseClicked(evt);
            }
        });
        _menuCard.add(_snacksLabel);
        _snacksLabel.setBounds(546, 387, 254, 44);

        _dessertsLabel.setFont(new java.awt.Font("FreeSans", 1, 36)); // NOI18N
        _dessertsLabel.setForeground(java.awt.Color.white);
        _dessertsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _dessertsLabel.setText("POSTRES");
        _menuCard.add(_dessertsLabel);
        _dessertsLabel.setBounds(863, 387, 192, 44);

        _cardsPanel.add(_menuCard, "card2");

        _pizzasCard.setBackground(new java.awt.Color(0, 98, 183));
        _pizzasCard.setLayout(null);

        _draggableLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _draggableLabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        _pizzasCard.add(_draggableLabel);
        _draggableLabel.setBounds(290, 0, 96, 96);

        _pizzaMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _pizzaMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pizzaMinusLabel.setForeground(java.awt.Color.white);
        _pizzaMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzaMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _pizzaMinusLabel.setOpaque(true);
        _pizzaMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pizzaMinusLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_pizzaMinusLabel);
        _pizzaMinusLabel.setBounds(488, 110, 48, 24);

        _pizzaNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _pizzaNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pizzaNumberLabel.setForeground(java.awt.Color.white);
        _pizzaNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzaNumberLabel.setText("2");
        _pizzaNumberLabel.setOpaque(true);
        _pizzasCard.add(_pizzaNumberLabel);
        _pizzaNumberLabel.setBounds(536, 110, 48, 24);

        _pizzaAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _pizzaAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pizzaAddLabel.setForeground(java.awt.Color.white);
        _pizzaAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzaAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _pizzaAddLabel.setOpaque(true);
        _pizzaAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pizzaAddLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_pizzaAddLabel);
        _pizzaAddLabel.setBounds(584, 110, 48, 24);

        _pizzaField.setBackground(new java.awt.Color(0, 98, 183));
        _pizzaField.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pizzaField.setForeground(java.awt.Color.white);
        _pizzaField.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        _pizzaField.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        _pizzaField.setOpaque(false);
        _pizzasCard.add(_pizzaField);
        _pizzaField.setBounds(450, 480, 220, 30);

        _tickMediumLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickMediumLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickMediumLabel);
        _tickMediumLabel.setBounds(1004, 60, 16, 16);

        _tickFamiliarLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickFamiliarLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickFamiliarLabel);
        _tickFamiliarLabel.setBounds(1092, 60, 16, 16);

        _mediumLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _mediumLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/medium.png"))); // NOI18N
        _mediumLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _mediumLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_mediumLabel);
        _mediumLabel.setBounds(956, 12, 64, 64);

        _familiarLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _familiarLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/familiar.png"))); // NOI18N
        _familiarLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _familiarLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_familiarLabel);
        _familiarLabel.setBounds(1044, 12, 64, 64);

        _familiarTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _familiarTittleLabel.setForeground(java.awt.Color.white);
        _familiarTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _familiarTittleLabel.setText("Familiar");
        _pizzasCard.add(_familiarTittleLabel);
        _familiarTittleLabel.setBounds(1032, 76, 88, 23);

        _mediumTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _mediumTittleLabel.setForeground(java.awt.Color.white);
        _mediumTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _mediumTittleLabel.setText("Mediana");
        _pizzasCard.add(_mediumTittleLabel);
        _mediumTittleLabel.setBounds(944, 76, 88, 23);

        _deleteLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _deleteLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/garbage.png"))); // NOI18N
        _deleteLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _deleteLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_deleteLabel);
        _deleteLabel.setBounds(1044, 520, 64, 64);

        _saveLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _saveLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/save.png"))); // NOI18N
        _saveLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _saveLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_saveLabel);
        _saveLabel.setBounds(956, 520, 64, 64);

        _saveTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _saveTittleLabel.setForeground(java.awt.Color.white);
        _saveTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _saveTittleLabel.setText("Nueva");
        _pizzasCard.add(_saveTittleLabel);
        _saveTittleLabel.setBounds(944, 584, 88, 23);

        _deleteTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _deleteTittleLabel.setForeground(java.awt.Color.white);
        _deleteTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _deleteTittleLabel.setText("Eliminar");
        _pizzasCard.add(_deleteTittleLabel);
        _deleteTittleLabel.setBounds(1032, 584, 88, 23);

        _tickCreamLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickCreamLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickCreamLabel);
        _tickCreamLabel.setBounds(236, 60, 16, 16);

        _tickBarbacueLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickBarbacueLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickBarbacueLabel);
        _tickBarbacueLabel.setBounds(148, 60, 16, 16);

        _tickTomatoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickTomatoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickTomatoLabel);
        _tickTomatoLabel.setBounds(60, 60, 16, 16);

        _tickBourbonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickBourbonLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickBourbonLabel);
        _tickBourbonLabel.setBounds(60, 160, 16, 16);

        _tickFinizzimaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickFinizzimaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickFinizzimaLabel);
        _tickFinizzimaLabel.setBounds(60, 568, 16, 16);

        _tickOriginalLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickOriginalLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickOriginalLabel);
        _tickOriginalLabel.setBounds(148, 568, 16, 16);

        _tickPanLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickPanLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickPanLabel);
        _tickPanLabel.setBounds(236, 568, 16, 16);

        _tickOliveLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickOliveLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickOliveLabel);
        _tickOliveLabel.setBounds(584, 72, 16, 16);

        _tickAnchovyLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickAnchovyLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickAnchovyLabel);
        _tickAnchovyLabel.setBounds(684, 92, 16, 16);

        _tickTunaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickTunaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickTunaLabel);
        _tickTunaLabel.setBounds(769, 149, 16, 16);

        _tickBaconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickBaconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickBaconLabel);
        _tickBaconLabel.setBounds(826, 234, 16, 16);

        _tickOnionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickOnionLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickOnionLabel);
        _tickOnionLabel.setBounds(846, 334, 16, 16);

        _tickMushroomLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickMushroomLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickMushroomLabel);
        _tickMushroomLabel.setBounds(826, 434, 16, 16);

        _tickYorkLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickYorkLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickYorkLabel);
        _tickYorkLabel.setBounds(769, 519, 16, 16);

        _tickHamLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickHamLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickHamLabel);
        _tickHamLabel.setBounds(684, 576, 16, 16);

        _tickCornLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickCornLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickCornLabel);
        _tickCornLabel.setBounds(584, 596, 16, 16);

        _tickPepperoniLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickPepperoniLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickPepperoniLabel);
        _tickPepperoniLabel.setBounds(484, 576, 16, 16);

        _tickPepperLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickPepperLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickPepperLabel);
        _tickPepperLabel.setBounds(399, 519, 16, 16);

        _tickPineappleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickPineappleLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickPineappleLabel);
        _tickPineappleLabel.setBounds(342, 434, 16, 16);

        _tickChickenLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickChickenLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickChickenLabel);
        _tickChickenLabel.setBounds(322, 334, 16, 16);

        _tickBeefLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickBeefLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickBeefLabel);
        _tickBeefLabel.setBounds(342, 234, 16, 16);

        _tickTomatoeLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickTomatoeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickTomatoeLabel);
        _tickTomatoeLabel.setBounds(399, 149, 16, 16);

        _tickCaramelLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tickCaramelLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tick.png"))); // NOI18N
        _pizzasCard.add(_tickCaramelLabel);
        _tickCaramelLabel.setBounds(484, 92, 16, 16);

        _anchovyLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _anchovyLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_11anchovy.png"))); // NOI18N
        _anchovyLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _anchovyLabelMouseDragged(evt);
            }
        });
        _anchovyLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _anchovyLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _anchovyLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_anchovyLabel);
        _anchovyLabel.setBounds(612, 20, 96, 96);

        _beefLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _beefLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_beef.png"))); // NOI18N
        _beefLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _beefLabelMouseDragged(evt);
            }
        });
        _beefLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _beefLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _beefLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_beefLabel);
        _beefLabel.setBounds(270, 162, 96, 96);

        _pizzaChickenLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzaChickenLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_chicken.png"))); // NOI18N
        _pizzaChickenLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _pizzaChickenLabelMouseDragged(evt);
            }
        });
        _pizzaChickenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _pizzaChickenLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pizzaChickenLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_pizzaChickenLabel);
        _pizzaChickenLabel.setBounds(250, 262, 96, 96);

        _oliveLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _oliveLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_olive.png"))); // NOI18N
        _oliveLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _oliveLabelMouseDragged(evt);
            }
        });
        _oliveLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _oliveLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _oliveLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_oliveLabel);
        _oliveLabel.setBounds(512, 0, 96, 96);

        _pepperoniLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepperoniLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_pepperoni.png"))); // NOI18N
        _pepperoniLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _pepperoniLabelMouseDragged(evt);
            }
        });
        _pepperoniLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _pepperoniLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pepperoniLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_pepperoniLabel);
        _pepperoniLabel.setBounds(412, 504, 96, 96);

        _cornLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cornLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_corn.png"))); // NOI18N
        _cornLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _cornLabelMouseDragged(evt);
            }
        });
        _cornLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _cornLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _cornLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_cornLabel);
        _cornLabel.setBounds(512, 524, 96, 96);

        _hamLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _hamLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_ham.png"))); // NOI18N
        _hamLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _hamLabelMouseDragged(evt);
            }
        });
        _hamLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _hamLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _hamLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_hamLabel);
        _hamLabel.setBounds(612, 504, 96, 96);

        _baconLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _baconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_bacon.png"))); // NOI18N
        _baconLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _baconLabelMouseDragged(evt);
            }
        });
        _baconLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _baconLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _baconLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_baconLabel);
        _baconLabel.setBounds(754, 162, 96, 96);

        _onionLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _onionLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_onion.png"))); // NOI18N
        _onionLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _onionLabelMouseDragged(evt);
            }
        });
        _onionLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _onionLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _onionLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_onionLabel);
        _onionLabel.setBounds(774, 262, 96, 96);

        _mushroomLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _mushroomLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_mushroom.png"))); // NOI18N
        _mushroomLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _mushroomLabelMouseDragged(evt);
            }
        });
        _mushroomLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _mushroomLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _mushroomLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_mushroomLabel);
        _mushroomLabel.setBounds(754, 362, 96, 96);

        _yorkLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _yorkLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_york.png"))); // NOI18N
        _yorkLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _yorkLabelMouseDragged(evt);
            }
        });
        _yorkLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _yorkLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _yorkLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_yorkLabel);
        _yorkLabel.setBounds(697, 447, 96, 96);

        _pineappleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pineappleLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_pineapple.png"))); // NOI18N
        _pineappleLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _pineappleLabelMouseDragged(evt);
            }
        });
        _pineappleLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _pineappleLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pineappleLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_pineappleLabel);
        _pineappleLabel.setBounds(270, 362, 96, 96);

        _tunaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tunaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_1tuna.png"))); // NOI18N
        _tunaLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _tunaLabelMouseDragged(evt);
            }
        });
        _tunaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _tunaLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tunaLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_tunaLabel);
        _tunaLabel.setBounds(697, 77, 96, 96);

        _pepperLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepperLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_pepper.png"))); // NOI18N
        _pepperLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _pepperLabelMouseDragged(evt);
            }
        });
        _pepperLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _pepperLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pepperLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_pepperLabel);
        _pepperLabel.setBounds(327, 447, 96, 96);

        _caramelPizzaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _caramelPizzaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/rsz_caramel.png"))); // NOI18N
        _caramelPizzaLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _caramelPizzaLabelMouseDragged(evt);
            }
        });
        _caramelPizzaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _caramelPizzaLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _caramelPizzaLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_caramelPizzaLabel);
        _caramelPizzaLabel.setBounds(412, 20, 96, 96);

        _tomateLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tomateLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoe.png"))); // NOI18N
        _tomateLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _tomateLabelMouseDragged(evt);
            }
        });
        _tomateLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _tomateLabelMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tomateLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_tomateLabel);
        _tomateLabel.setBounds(327, 77, 96, 96);

        _bourbonLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _bourbonLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bourbon.png"))); // NOI18N
        _bourbonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _bourbonLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_bourbonLabel);
        _bourbonLabel.setBounds(12, 112, 64, 64);

        _panLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _panLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pan_1.png"))); // NOI18N
        _panLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        _panLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _panLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_panLabel);
        _panLabel.setBounds(188, 520, 64, 64);

        _barbacueLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _barbacueLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/barbacue.png"))); // NOI18N
        _barbacueLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _barbacueLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_barbacueLabel);
        _barbacueLabel.setBounds(100, 12, 64, 64);

        _creamLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _creamLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cream.png"))); // NOI18N
        _creamLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _creamLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_creamLabel);
        _creamLabel.setBounds(188, 12, 64, 64);

        _barbacueTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _barbacueTittleLabel.setForeground(java.awt.Color.white);
        _barbacueTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _barbacueTittleLabel.setText("Barbacoa");
        _pizzasCard.add(_barbacueTittleLabel);
        _barbacueTittleLabel.setBounds(88, 76, 88, 23);

        _tomatoTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _tomatoTittleLabel.setForeground(java.awt.Color.white);
        _tomatoTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tomatoTittleLabel.setText("Tomate");
        _pizzasCard.add(_tomatoTittleLabel);
        _tomatoTittleLabel.setBounds(0, 76, 88, 23);

        _creamTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _creamTittleLabel.setForeground(java.awt.Color.white);
        _creamTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _creamTittleLabel.setText("Crema");
        _pizzasCard.add(_creamTittleLabel);
        _creamTittleLabel.setBounds(176, 76, 88, 23);

        _bourbonTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _bourbonTittleLabel.setForeground(java.awt.Color.white);
        _bourbonTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _bourbonTittleLabel.setText("Bourbon");
        _pizzasCard.add(_bourbonTittleLabel);
        _bourbonTittleLabel.setBounds(0, 176, 88, 23);

        _tomatoLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tomatoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomato.png"))); // NOI18N
        _tomatoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _tomatoLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_tomatoLabel);
        _tomatoLabel.setBounds(12, 12, 64, 64);

        _finizzimaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _finizzimaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/finisima_1.png"))); // NOI18N
        _finizzimaLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        _finizzimaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _finizzimaLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_finizzimaLabel);
        _finizzimaLabel.setBounds(12, 520, 64, 64);

        _originalLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _originalLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/original_1.png"))); // NOI18N
        _originalLabel.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        _originalLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _originalLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_originalLabel);
        _originalLabel.setBounds(100, 520, 64, 64);

        _finizzimaTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _finizzimaTittleLabel.setForeground(java.awt.Color.white);
        _finizzimaTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _finizzimaTittleLabel.setText("Finízzima");
        _pizzasCard.add(_finizzimaTittleLabel);
        _finizzimaTittleLabel.setBounds(0, 584, 88, 23);

        _originalTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _originalTittleLabel.setForeground(java.awt.Color.white);
        _originalTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _originalTittleLabel.setText("Original");
        _pizzasCard.add(_originalTittleLabel);
        _originalTittleLabel.setBounds(88, 584, 88, 23);

        _panTittleLabel.setFont(new java.awt.Font("FreeSans", 0, 18)); // NOI18N
        _panTittleLabel.setForeground(java.awt.Color.white);
        _panTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _panTittleLabel.setText("Pan");
        _pizzasCard.add(_panTittleLabel);
        _panTittleLabel.setBounds(176, 584, 88, 23);

        _nextLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _nextLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/next.png"))); // NOI18N
        _nextLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _nextLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_nextLabel);
        _nextLabel.setBounds(872, 246, 108, 128);

        _previousLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _previousLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/previous.png"))); // NOI18N
        _previousLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _previousLabelMouseClicked(evt);
            }
        });
        _pizzasCard.add(_previousLabel);
        _previousLabel.setBounds(140, 246, 108, 128);

        _cornsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cornsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png"))); // NOI18N
        _pizzasCard.add(_cornsLabel);
        _cornsLabel.setBounds(285, 0, 550, 620);

        _olivesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _olivesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png"))); // NOI18N
        _pizzasCard.add(_olivesLabel);
        _olivesLabel.setBounds(285, 0, 550, 620);

        _pineapplesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pineapplesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png"))); // NOI18N
        _pizzasCard.add(_pineapplesLabel);
        _pineapplesLabel.setBounds(285, 0, 550, 620);

        _caramelsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _caramelsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png"))); // NOI18N
        _pizzasCard.add(_caramelsLabel);
        _caramelsLabel.setBounds(285, 0, 550, 620);

        _onionsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _onionsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png"))); // NOI18N
        _pizzasCard.add(_onionsLabel);
        _onionsLabel.setBounds(285, 0, 550, 620);

        _peppersLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _peppersLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png"))); // NOI18N
        _pizzasCard.add(_peppersLabel);
        _peppersLabel.setBounds(285, 0, 550, 620);

        _mushroomsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _mushroomsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png"))); // NOI18N
        _pizzasCard.add(_mushroomsLabel);
        _mushroomsLabel.setBounds(285, 0, 550, 620);

        _tunasLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tunasLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png"))); // NOI18N
        _pizzasCard.add(_tunasLabel);
        _tunasLabel.setBounds(285, 0, 550, 620);

        _anchoviesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _anchoviesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png"))); // NOI18N
        _pizzasCard.add(_anchoviesLabel);
        _anchoviesLabel.setBounds(285, 0, 550, 620);

        _beefsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _beefsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png"))); // NOI18N
        _pizzasCard.add(_beefsLabel);
        _beefsLabel.setBounds(285, 0, 550, 620);

        _chickensLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chickensLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png"))); // NOI18N
        _pizzasCard.add(_chickensLabel);
        _chickensLabel.setBounds(285, 0, 550, 620);

        _yorksLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _yorksLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png"))); // NOI18N
        _pizzasCard.add(_yorksLabel);
        _yorksLabel.setBounds(285, 0, 550, 620);

        _hamsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _hamsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png"))); // NOI18N
        _pizzasCard.add(_hamsLabel);
        _hamsLabel.setBounds(285, 0, 550, 620);

        _baconsLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _baconsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png"))); // NOI18N
        _pizzasCard.add(_baconsLabel);
        _baconsLabel.setBounds(285, 0, 550, 620);

        _pepperonisLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepperonisLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png"))); // NOI18N
        _pizzasCard.add(_pepperonisLabel);
        _pepperonisLabel.setBounds(285, 0, 550, 620);

        _tomatoesLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tomatoesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png"))); // NOI18N
        _pizzasCard.add(_tomatoesLabel);
        _tomatoesLabel.setBounds(285, 0, 550, 620);

        _pizzaDrag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _pizzaDragMouseDragged(evt);
            }
        });
        _pizzaDrag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _pizzaDragMouseReleased(evt);
            }
        });
        _pizzasCard.add(_pizzaDrag);
        _pizzaDrag.setBounds(410, 160, 300, 300);

        _pizzaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pizzaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pizza.png"))); // NOI18N
        _pizzasCard.add(_pizzaLabel);
        _pizzaLabel.setBounds(285, 0, 550, 620);

        _dishLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _dishLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dish.png"))); // NOI18N
        _pizzasCard.add(_dishLabel);
        _dishLabel.setBounds(285, 0, 550, 620);

        _cardsPanel.add(_pizzasCard, "card2");

        _drinksCard.setBackground(new java.awt.Color(0, 98, 183));
        _drinksCard.setLayout(null);

        _containerPanel.setBackground(new java.awt.Color(0, 85, 159));
        _containerPanel.setMinimumSize(new java.awt.Dimension(200, 620));
        _containerPanel.setPreferredSize(new java.awt.Dimension(200, 620));

        _beverageLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _beverageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bottles.png"))); // NOI18N
        _beverageLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _beverageLabelMouseClicked(evt);
            }
        });

        _sodaLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _sodaLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beverages.png"))); // NOI18N
        _sodaLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _sodaLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout _containerPanelLayout = new javax.swing.GroupLayout(_containerPanel);
        _containerPanel.setLayout(_containerPanelLayout);
        _containerPanelLayout.setHorizontalGroup(
            _containerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_containerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(_containerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_beverageLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_sodaLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        _containerPanelLayout.setVerticalGroup(
            _containerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, _containerPanelLayout.createSequentialGroup()
                .addContainerGap(118, Short.MAX_VALUE)
                .addComponent(_sodaLabel)
                .addGap(128, 128, 128)
                .addComponent(_beverageLabel)
                .addGap(118, 118, 118))
        );

        _drinksCard.add(_containerPanel);
        _containerPanel.setBounds(0, 0, 200, 620);

        _drinksCardsPanel.setBackground(new java.awt.Color(0, 98, 183));
        _drinksCardsPanel.setLayout(new java.awt.CardLayout());

        _tapCard.setBackground(new java.awt.Color(0, 98, 183));
        _tapCard.setLayout(null);

        _sodaTrashLabel.setBackground(new java.awt.Color(0, 98, 183));
        _sodaTrashLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _sodaTrashLabel.setForeground(java.awt.Color.white);
        _sodaTrashLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _sodaTrashLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/trash.png"))); // NOI18N
        _sodaTrashLabel.setOpaque(true);
        _sodaTrashLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _sodaTrashLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_sodaTrashLabel);
        _sodaTrashLabel.setBounds(500, 430, 48, 48);

        _pepsiLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepsiLogo.png"))); // NOI18N
        _pepsiLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pepsiLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_pepsiLabel);
        _pepsiLabel.setBounds(48, 48, 128, 128);

        _lightLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lightLogo.png"))); // NOI18N
        _lightLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lightLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lightLabel);
        _lightLabel.setBounds(222, 48, 128, 128);

        _lemonLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lemonLogo.png"))); // NOI18N
        _lemonLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lemonLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lemonLabel);
        _lemonLabel.setBounds(570, 48, 128, 128);

        _orangeLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/orangeLogo.png"))); // NOI18N
        _orangeLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _orangeLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_orangeLabel);
        _orangeLabel.setBounds(396, 48, 128, 128);

        _zeroLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/zeroLogo.png"))); // NOI18N
        _zeroLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _zeroLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_zeroLabel);
        _zeroLabel.setBounds(744, 48, 128, 128);

        _tap1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tap1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tap.png"))); // NOI18N
        _tapCard.add(_tap1);
        _tap1.setBounds(48, 182, 128, 25);

        _tap2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tap2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tap.png"))); // NOI18N
        _tapCard.add(_tap2);
        _tap2.setBounds(222, 182, 128, 25);

        _tap3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tap3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tap.png"))); // NOI18N
        _tapCard.add(_tap3);
        _tap3.setBounds(396, 182, 128, 25);

        _tap4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tap4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tap.png"))); // NOI18N
        _tapCard.add(_tap4);
        _tap4.setBounds(570, 182, 128, 25);

        _tap5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _tap5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tap.png"))); // NOI18N
        _tapCard.add(_tap5);
        _tap5.setBounds(744, 182, 128, 25);

        _pepsiSquirtLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepsiSquirtLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepsiSquirt.png"))); // NOI18N
        _pepsiSquirtLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        _tapCard.add(_pepsiSquirtLabel);
        _pepsiSquirtLabel.setBounds(50, 200, 120, 110);

        _lightSquirtLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lightSquirtLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepsiSquirt.png"))); // NOI18N
        _lightSquirtLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        _tapCard.add(_lightSquirtLabel);
        _lightSquirtLabel.setBounds(220, 200, 130, 110);

        _orangeSquirtLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orangeSquirtLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/orangeSquirt.png"))); // NOI18N
        _orangeSquirtLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        _tapCard.add(_orangeSquirtLabel);
        _orangeSquirtLabel.setBounds(400, 200, 120, 110);

        _lemonSquirtLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lemonSquirtLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/lemonSquirt.png"))); // NOI18N
        _lemonSquirtLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        _tapCard.add(_lemonSquirtLabel);
        _lemonSquirtLabel.setBounds(570, 200, 130, 110);

        _zeroSquirtLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _zeroSquirtLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepsiSquirt.png"))); // NOI18N
        _zeroSquirtLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        _tapCard.add(_zeroSquirtLabel);
        _zeroSquirtLabel.setBounds(750, 200, 115, 110);

        _sodaCardboardLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _sodaCardboardLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ice.png"))); // NOI18N
        _sodaCardboardLabel.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                _sodaCardboardLabelMouseDragged(evt);
            }
        });
        _sodaCardboardLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                _sodaCardboardLabelMouseReleased(evt);
            }
        });
        _tapCard.add(_sodaCardboardLabel);
        _sodaCardboardLabel.setBounds(396, 280, 128, 192);

        _sodaMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _sodaMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _sodaMinusLabel.setForeground(java.awt.Color.white);
        _sodaMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _sodaMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _sodaMinusLabel.setOpaque(true);
        _sodaMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _sodaMinusLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_sodaMinusLabel);
        _sodaMinusLabel.setBounds(380, 490, 48, 24);

        _sodaNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _sodaNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _sodaNumberLabel.setForeground(java.awt.Color.white);
        _sodaNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _sodaNumberLabel.setText("2");
        _sodaNumberLabel.setOpaque(true);
        _sodaNumberLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _sodaNumberLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_sodaNumberLabel);
        _sodaNumberLabel.setBounds(440, 490, 48, 24);

        _sodaAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _sodaAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _sodaAddLabel.setForeground(java.awt.Color.white);
        _sodaAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _sodaAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _sodaAddLabel.setOpaque(true);
        _sodaAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _sodaAddLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_sodaAddLabel);
        _sodaAddLabel.setBounds(500, 490, 48, 24);

        _pepsiAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _pepsiAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pepsiAddLabel.setForeground(java.awt.Color.white);
        _pepsiAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepsiAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _pepsiAddLabel.setOpaque(true);
        _pepsiAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pepsiAddLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_pepsiAddLabel);
        _pepsiAddLabel.setBounds(134, 10, 40, 24);

        _pepsiNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _pepsiNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pepsiNumberLabel.setForeground(java.awt.Color.white);
        _pepsiNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepsiNumberLabel.setText("2");
        _pepsiNumberLabel.setOpaque(true);
        _pepsiNumberLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pepsiNumberLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_pepsiNumberLabel);
        _pepsiNumberLabel.setBounds(90, 10, 44, 24);

        _pepsiMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _pepsiMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _pepsiMinusLabel.setForeground(java.awt.Color.white);
        _pepsiMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _pepsiMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _pepsiMinusLabel.setOpaque(true);
        _pepsiMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _pepsiMinusLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_pepsiMinusLabel);
        _pepsiMinusLabel.setBounds(48, 10, 42, 24);

        _lightMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _lightMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _lightMinusLabel.setForeground(java.awt.Color.white);
        _lightMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lightMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _lightMinusLabel.setOpaque(true);
        _lightMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lightMinusLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lightMinusLabel);
        _lightMinusLabel.setBounds(222, 10, 42, 24);

        _lightNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _lightNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _lightNumberLabel.setForeground(java.awt.Color.white);
        _lightNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lightNumberLabel.setText("2");
        _lightNumberLabel.setOpaque(true);
        _lightNumberLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lightNumberLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lightNumberLabel);
        _lightNumberLabel.setBounds(264, 10, 44, 24);

        _lightAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _lightAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _lightAddLabel.setForeground(java.awt.Color.white);
        _lightAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lightAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _lightAddLabel.setOpaque(true);
        _lightAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lightAddLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lightAddLabel);
        _lightAddLabel.setBounds(308, 10, 40, 24);

        _orangeMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _orangeMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _orangeMinusLabel.setForeground(java.awt.Color.white);
        _orangeMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orangeMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _orangeMinusLabel.setOpaque(true);
        _orangeMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _orangeMinusLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_orangeMinusLabel);
        _orangeMinusLabel.setBounds(396, 10, 42, 24);

        _orangeNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _orangeNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _orangeNumberLabel.setForeground(java.awt.Color.white);
        _orangeNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orangeNumberLabel.setText("2");
        _orangeNumberLabel.setOpaque(true);
        _orangeNumberLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _orangeNumberLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_orangeNumberLabel);
        _orangeNumberLabel.setBounds(438, 10, 44, 24);

        _orangeAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _orangeAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _orangeAddLabel.setForeground(java.awt.Color.white);
        _orangeAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _orangeAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _orangeAddLabel.setOpaque(true);
        _orangeAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _orangeAddLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_orangeAddLabel);
        _orangeAddLabel.setBounds(482, 10, 40, 24);

        _lemonMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _lemonMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _lemonMinusLabel.setForeground(java.awt.Color.white);
        _lemonMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lemonMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _lemonMinusLabel.setOpaque(true);
        _lemonMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lemonMinusLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lemonMinusLabel);
        _lemonMinusLabel.setBounds(570, 10, 42, 24);

        _lemonNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _lemonNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _lemonNumberLabel.setForeground(java.awt.Color.white);
        _lemonNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lemonNumberLabel.setText("2");
        _lemonNumberLabel.setOpaque(true);
        _lemonNumberLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lemonNumberLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lemonNumberLabel);
        _lemonNumberLabel.setBounds(612, 10, 44, 24);

        _lemonAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _lemonAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _lemonAddLabel.setForeground(java.awt.Color.white);
        _lemonAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _lemonAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _lemonAddLabel.setOpaque(true);
        _lemonAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _lemonAddLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_lemonAddLabel);
        _lemonAddLabel.setBounds(656, 10, 40, 24);

        _zeroMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _zeroMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _zeroMinusLabel.setForeground(java.awt.Color.white);
        _zeroMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _zeroMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _zeroMinusLabel.setOpaque(true);
        _zeroMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _zeroMinusLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_zeroMinusLabel);
        _zeroMinusLabel.setBounds(744, 10, 42, 24);

        _zeroNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _zeroNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _zeroNumberLabel.setForeground(java.awt.Color.white);
        _zeroNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _zeroNumberLabel.setText("2");
        _zeroNumberLabel.setOpaque(true);
        _zeroNumberLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _zeroNumberLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_zeroNumberLabel);
        _zeroNumberLabel.setBounds(786, 10, 44, 24);

        _zeroAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _zeroAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _zeroAddLabel.setForeground(java.awt.Color.white);
        _zeroAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _zeroAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _zeroAddLabel.setOpaque(true);
        _zeroAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _zeroAddLabelMouseClicked(evt);
            }
        });
        _tapCard.add(_zeroAddLabel);
        _zeroAddLabel.setBounds(830, 10, 40, 24);

        _drinksCardsPanel.add(_tapCard, "card2");

        _beverageCard.setBackground(new java.awt.Color(0, 98, 183));

        _waterTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _waterTittleLabel.setForeground(java.awt.Color.white);
        _waterTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _waterTittleLabel.setText("Agua (50 cl)");

        _redBullTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _redBullTittleLabel.setForeground(java.awt.Color.white);
        _redBullTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _redBullTittleLabel.setText("Red Bull");

        _waterLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/water.png"))); // NOI18N
        _waterLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _waterLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _waterLabelMouseEntered(evt);
            }
        });

        _waterNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _waterNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _waterNumberLabel.setForeground(java.awt.Color.white);
        _waterNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _waterNumberLabel.setText("2");
        _waterNumberLabel.setOpaque(true);

        _waterAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _waterAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _waterAddLabel.setForeground(java.awt.Color.white);
        _waterAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _waterAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _waterAddLabel.setOpaque(true);
        _waterAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _waterAddLabelMouseClicked(evt);
            }
        });

        _waterMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _waterMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _waterMinusLabel.setForeground(java.awt.Color.white);
        _waterMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _waterMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _waterMinusLabel.setOpaque(true);
        _waterMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _waterMinusLabelMouseClicked(evt);
            }
        });

        _redBullLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/redbull.png"))); // NOI18N
        _redBullLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _redBullLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _redBullLabelMouseEntered(evt);
            }
        });

        _redBullNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _redBullNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _redBullNumberLabel.setForeground(java.awt.Color.white);
        _redBullNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _redBullNumberLabel.setText("2");
        _redBullNumberLabel.setOpaque(true);

        _redBullAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _redBullAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _redBullAddLabel.setForeground(java.awt.Color.white);
        _redBullAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _redBullAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _redBullAddLabel.setOpaque(true);
        _redBullAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _redBullAddLabelMouseClicked(evt);
            }
        });

        _redBullMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _redBullMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _redBullMinusLabel.setForeground(java.awt.Color.white);
        _redBullMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _redBullMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _redBullMinusLabel.setOpaque(true);
        _redBullMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _redBullMinusLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout _beverageCardLayout = new javax.swing.GroupLayout(_beverageCard);
        _beverageCard.setLayout(_beverageCardLayout);
        _beverageCardLayout.setHorizontalGroup(
            _beverageCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_beverageCardLayout.createSequentialGroup()
                .addGap(255, 255, 255)
                .addGroup(_beverageCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(_beverageCardLayout.createSequentialGroup()
                        .addComponent(_waterLabel)
                        .addGap(26, 26, 26)
                        .addComponent(_redBullLabel))
                    .addGroup(_beverageCardLayout.createSequentialGroup()
                        .addComponent(_waterTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(84, 84, 84)
                        .addComponent(_redBullTittleLabel))
                    .addGroup(_beverageCardLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(_waterMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(_waterNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(_waterAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(_redBullMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(_redBullNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(_redBullAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(255, Short.MAX_VALUE))
        );
        _beverageCardLayout.setVerticalGroup(
            _beverageCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_beverageCardLayout.createSequentialGroup()
                .addGap(184, 184, 184)
                .addGroup(_beverageCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_waterTittleLabel)
                    .addComponent(_redBullTittleLabel))
                .addGap(6, 6, 6)
                .addGroup(_beverageCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_waterLabel)
                    .addComponent(_redBullLabel))
                .addGap(6, 6, 6)
                .addGroup(_beverageCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_waterMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_waterNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_waterAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_redBullMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_redBullNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_redBullAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(185, Short.MAX_VALUE))
        );

        _drinksCardsPanel.add(_beverageCard, "card2");

        _drinksCard.add(_drinksCardsPanel);
        _drinksCardsPanel.setBounds(200, 0, 920, 620);

        _cardsPanel.add(_drinksCard, "card2");

        _snacksCard.setBackground(new java.awt.Color(0, 98, 183));

        _potatoesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/potatoes.png"))); // NOI18N
        _potatoesLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _potatoesLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _potatoesLabelMouseEntered(evt);
            }
        });

        _potatoesNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _potatoesNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _potatoesNumberLabel.setForeground(java.awt.Color.white);
        _potatoesNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _potatoesNumberLabel.setText("2");
        _potatoesNumberLabel.setOpaque(true);

        _potatoesAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _potatoesAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _potatoesAddLabel.setForeground(java.awt.Color.white);
        _potatoesAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _potatoesAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _potatoesAddLabel.setOpaque(true);
        _potatoesAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _potatoesAddLabelMouseClicked(evt);
            }
        });

        _potatoesMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _potatoesMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _potatoesMinusLabel.setForeground(java.awt.Color.white);
        _potatoesMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _potatoesMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _potatoesMinusLabel.setOpaque(true);
        _potatoesMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _potatoesMinusLabelMouseClicked(evt);
            }
        });

        _chickenTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chickenTittleLabel.setForeground(java.awt.Color.white);
        _chickenTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chickenTittleLabel.setText("Combo de pollo");

        _chickenLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chicken.png"))); // NOI18N
        _chickenLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _chickenLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _chickenLabelMouseEntered(evt);
            }
        });

        _chickenNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _chickenNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chickenNumberLabel.setForeground(java.awt.Color.white);
        _chickenNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chickenNumberLabel.setText("2");
        _chickenNumberLabel.setOpaque(true);

        _chickenAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _chickenAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chickenAddLabel.setForeground(java.awt.Color.white);
        _chickenAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chickenAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _chickenAddLabel.setOpaque(true);
        _chickenAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _chickenAddLabelMouseClicked(evt);
            }
        });

        _chickenMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _chickenMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chickenMinusLabel.setForeground(java.awt.Color.white);
        _chickenMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chickenMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _chickenMinusLabel.setOpaque(true);
        _chickenMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _chickenMinusLabelMouseClicked(evt);
            }
        });

        _kickersLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/kickers.png"))); // NOI18N
        _kickersLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _kickersLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _kickersLabelMouseEntered(evt);
            }
        });

        _kickersNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _kickersNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _kickersNumberLabel.setForeground(java.awt.Color.white);
        _kickersNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _kickersNumberLabel.setText("2");
        _kickersNumberLabel.setOpaque(true);

        _kickersAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _kickersAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _kickersAddLabel.setForeground(java.awt.Color.white);
        _kickersAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _kickersAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _kickersAddLabel.setOpaque(true);
        _kickersAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _kickersAddLabelMouseClicked(evt);
            }
        });

        _kickersMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _kickersMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _kickersMinusLabel.setForeground(java.awt.Color.white);
        _kickersMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _kickersMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _kickersMinusLabel.setOpaque(true);
        _kickersMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _kickersMinusLabelMouseClicked(evt);
            }
        });

        _wingsLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/wings.png"))); // NOI18N
        _wingsLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _wingsLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _wingsLabelMouseEntered(evt);
            }
        });

        _wingsNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _wingsNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingsNumberLabel.setForeground(java.awt.Color.white);
        _wingsNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingsNumberLabel.setText("2");
        _wingsNumberLabel.setOpaque(true);

        _wingsAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _wingsAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingsAddLabel.setForeground(java.awt.Color.white);
        _wingsAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingsAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _wingsAddLabel.setOpaque(true);
        _wingsAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _wingsAddLabelMouseClicked(evt);
            }
        });

        _wingsMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _wingsMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingsMinusLabel.setForeground(java.awt.Color.white);
        _wingsMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingsMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _wingsMinusLabel.setOpaque(true);
        _wingsMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _wingsMinusLabelMouseClicked(evt);
            }
        });

        _wingLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/wing.png"))); // NOI18N
        _wingLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _wingLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _wingLabelMouseEntered(evt);
            }
        });

        _wingNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _wingNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingNumberLabel.setForeground(java.awt.Color.white);
        _wingNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingNumberLabel.setText("2");
        _wingNumberLabel.setOpaque(true);

        _wingAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _wingAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingAddLabel.setForeground(java.awt.Color.white);
        _wingAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _wingAddLabel.setOpaque(true);
        _wingAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _wingAddLabelMouseClicked(evt);
            }
        });

        _wingMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _wingMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingMinusLabel.setForeground(java.awt.Color.white);
        _wingMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _wingMinusLabel.setOpaque(true);
        _wingMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _wingMinusLabelMouseClicked(evt);
            }
        });

        _cheeseBreadLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cheeseBread.png"))); // NOI18N
        _cheeseBreadLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _cheeseBreadLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _cheeseBreadLabelMouseEntered(evt);
            }
        });

        _cheeseBreadNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _cheeseBreadNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cheeseBreadNumberLabel.setForeground(java.awt.Color.white);
        _cheeseBreadNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cheeseBreadNumberLabel.setText("2");
        _cheeseBreadNumberLabel.setOpaque(true);

        _cheeseBreadAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _cheeseBreadAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cheeseBreadAddLabel.setForeground(java.awt.Color.white);
        _cheeseBreadAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cheeseBreadAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _cheeseBreadAddLabel.setOpaque(true);
        _cheeseBreadAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _cheeseBreadAddLabelMouseClicked(evt);
            }
        });

        _cheeseBreadMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _cheeseBreadMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cheeseBreadMinusLabel.setForeground(java.awt.Color.white);
        _cheeseBreadMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cheeseBreadMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _cheeseBreadMinusLabel.setOpaque(true);
        _cheeseBreadMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _cheeseBreadMinusLabelMouseClicked(evt);
            }
        });

        _strippersLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/strippers.png"))); // NOI18N
        _strippersLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _strippersLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _strippersLabelMouseEntered(evt);
            }
        });

        _wingsTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingsTittleLabel.setForeground(java.awt.Color.white);
        _wingsTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingsTittleLabel.setText("Combo de alitas");

        _breadTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _breadTittleLabel.setForeground(java.awt.Color.white);
        _breadTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _breadTittleLabel.setText("Pan de ajo");

        _cheeseBreadTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cheeseBreadTittleLabel.setForeground(java.awt.Color.white);
        _cheeseBreadTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cheeseBreadTittleLabel.setText("Pan de ajo con queso");

        _kickersTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _kickersTittleLabel.setForeground(java.awt.Color.white);
        _kickersTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _kickersTittleLabel.setText("Kickers");

        _wingTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _wingTittleLabel.setForeground(java.awt.Color.white);
        _wingTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _wingTittleLabel.setText("Alitas de pollo");

        _strippersTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strippersTittleLabel.setForeground(java.awt.Color.white);
        _strippersTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strippersTittleLabel.setText("Strippers");

        _potatoesTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _potatoesTittleLabel.setForeground(java.awt.Color.white);
        _potatoesTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _potatoesTittleLabel.setText("Patatas grill");

        _strippersNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _strippersNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strippersNumberLabel.setForeground(java.awt.Color.white);
        _strippersNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strippersNumberLabel.setText("2");
        _strippersNumberLabel.setOpaque(true);

        _strippersAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _strippersAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strippersAddLabel.setForeground(java.awt.Color.white);
        _strippersAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strippersAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _strippersAddLabel.setOpaque(true);
        _strippersAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _strippersAddLabelMouseClicked(evt);
            }
        });

        _strippersMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _strippersMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strippersMinusLabel.setForeground(java.awt.Color.white);
        _strippersMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strippersMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _strippersMinusLabel.setOpaque(true);
        _strippersMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _strippersMinusLabelMouseClicked(evt);
            }
        });

        _breadLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bread.png"))); // NOI18N
        _breadLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _breadLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _breadLabelMouseEntered(evt);
            }
        });

        _breadNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _breadNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _breadNumberLabel.setForeground(java.awt.Color.white);
        _breadNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _breadNumberLabel.setText("2");
        _breadNumberLabel.setOpaque(true);

        _breadAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _breadAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _breadAddLabel.setForeground(java.awt.Color.white);
        _breadAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _breadAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _breadAddLabel.setOpaque(true);
        _breadAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _breadAddLabelMouseClicked(evt);
            }
        });

        _breadMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _breadMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _breadMinusLabel.setForeground(java.awt.Color.white);
        _breadMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _breadMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _breadMinusLabel.setOpaque(true);
        _breadMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _breadMinusLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout _snacksCardLayout = new javax.swing.GroupLayout(_snacksCard);
        _snacksCard.setLayout(_snacksCardLayout);
        _snacksCardLayout.setHorizontalGroup(
            _snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_snacksCardLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(_snacksCardLayout.createSequentialGroup()
                        .addComponent(_kickersTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(_wingTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(_strippersTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(_potatoesTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(_snacksCardLayout.createSequentialGroup()
                        .addComponent(_kickersLabel)
                        .addGap(26, 26, 26)
                        .addComponent(_wingLabel)
                        .addGap(26, 26, 26)
                        .addComponent(_strippersLabel)
                        .addGap(26, 26, 26)
                        .addComponent(_potatoesLabel))
                    .addGroup(_snacksCardLayout.createSequentialGroup()
                        .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(_snacksCardLayout.createSequentialGroup()
                                .addComponent(_chickenLabel)
                                .addGap(26, 26, 26)
                                .addComponent(_wingsLabel)
                                .addGap(26, 26, 26)
                                .addComponent(_cheeseBreadLabel))
                            .addGroup(_snacksCardLayout.createSequentialGroup()
                                .addComponent(_chickenTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(_wingsTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(_cheeseBreadTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(26, 26, 26)
                        .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(_breadTittleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(_breadLabel)))
                    .addGroup(_snacksCardLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(_snacksCardLayout.createSequentialGroup()
                                .addComponent(_chickenMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_chickenNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_chickenAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(_wingsMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_wingsNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_wingsAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(_cheeseBreadMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_cheeseBreadNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_cheeseBreadAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(_breadMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_breadNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_breadAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(_snacksCardLayout.createSequentialGroup()
                                .addComponent(_kickersMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_kickersNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_kickersAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(_wingMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_wingNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_wingAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(_strippersMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_strippersNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_strippersAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(_potatoesMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_potatoesNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(12, 12, 12)
                                .addComponent(_potatoesAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(137, Short.MAX_VALUE))
        );
        _snacksCardLayout.setVerticalGroup(
            _snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_snacksCardLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_chickenTittleLabel)
                    .addComponent(_wingsTittleLabel)
                    .addComponent(_cheeseBreadTittleLabel)
                    .addComponent(_breadTittleLabel))
                .addGap(6, 6, 6)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_chickenLabel)
                    .addComponent(_wingsLabel)
                    .addComponent(_cheeseBreadLabel)
                    .addComponent(_breadLabel))
                .addGap(6, 6, 6)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_chickenMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chickenNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chickenAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_wingsMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_wingsNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_wingsAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_cheeseBreadMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_cheeseBreadNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_cheeseBreadAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_breadMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_breadNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_breadAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_kickersTittleLabel)
                    .addComponent(_wingTittleLabel)
                    .addComponent(_strippersTittleLabel)
                    .addComponent(_potatoesTittleLabel))
                .addGap(6, 6, 6)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_kickersLabel)
                    .addComponent(_wingLabel)
                    .addComponent(_strippersLabel)
                    .addComponent(_potatoesLabel))
                .addGap(6, 6, 6)
                .addGroup(_snacksCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_kickersMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_kickersNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_kickersAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_wingMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_wingNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_wingAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_strippersMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_strippersNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_strippersAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_potatoesMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_potatoesNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_potatoesAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        _cardsPanel.add(_snacksCard, "card2");

        _dessertsCard.setBackground(new java.awt.Color(0, 98, 183));

        _strawberryLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/strawberry-cheescake.png"))); // NOI18N
        _strawberryLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _strawberryLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _strawberryLabelMouseEntered(evt);
            }
        });

        _strawberryNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _strawberryNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strawberryNumberLabel.setForeground(java.awt.Color.white);
        _strawberryNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strawberryNumberLabel.setText("2");
        _strawberryNumberLabel.setOpaque(true);

        _strawberryAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _strawberryAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strawberryAddLabel.setForeground(java.awt.Color.white);
        _strawberryAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strawberryAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _strawberryAddLabel.setOpaque(true);
        _strawberryAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _strawberryAddLabelMouseClicked(evt);
            }
        });

        _strawberryMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _strawberryMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strawberryMinusLabel.setForeground(java.awt.Color.white);
        _strawberryMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strawberryMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _strawberryMinusLabel.setOpaque(true);
        _strawberryMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _strawberryMinusLabelMouseClicked(evt);
            }
        });

        _appleLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/apple.png"))); // NOI18N
        _appleLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _appleLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _appleLabelMouseEntered(evt);
            }
        });

        _appleNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _appleNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _appleNumberLabel.setForeground(java.awt.Color.white);
        _appleNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _appleNumberLabel.setText("2");
        _appleNumberLabel.setOpaque(true);

        _appleAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _appleAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _appleAddLabel.setForeground(java.awt.Color.white);
        _appleAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _appleAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _appleAddLabel.setOpaque(true);
        _appleAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _appleAddLabelMouseClicked(evt);
            }
        });

        _appleMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _appleMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _appleMinusLabel.setForeground(java.awt.Color.white);
        _appleMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _appleMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _appleMinusLabel.setOpaque(true);
        _appleMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _appleMinusLabelMouseClicked(evt);
            }
        });

        _doughLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cookie-dough.png"))); // NOI18N
        _doughLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _doughLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _doughLabelMouseEntered(evt);
            }
        });

        _doughNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _doughNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _doughNumberLabel.setForeground(java.awt.Color.white);
        _doughNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _doughNumberLabel.setText("2");
        _doughNumberLabel.setOpaque(true);

        _doughAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _doughAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _doughAddLabel.setForeground(java.awt.Color.white);
        _doughAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _doughAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _doughAddLabel.setOpaque(true);
        _doughAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _doughAddLabelMouseClicked(evt);
            }
        });

        _doughMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _doughMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _doughMinusLabel.setForeground(java.awt.Color.white);
        _doughMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _doughMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _doughMinusLabel.setOpaque(true);
        _doughMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _doughMinusLabelMouseClicked(evt);
            }
        });

        _cookiesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cookies.png"))); // NOI18N
        _cookiesLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _cookiesLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _cookiesLabelMouseEntered(evt);
            }
        });

        _cookiesNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _cookiesNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cookiesNumberLabel.setForeground(java.awt.Color.white);
        _cookiesNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cookiesNumberLabel.setText("2");
        _cookiesNumberLabel.setOpaque(true);

        _cookiesAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _cookiesAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cookiesAddLabel.setForeground(java.awt.Color.white);
        _cookiesAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cookiesAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _cookiesAddLabel.setOpaque(true);
        _cookiesAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _cookiesAddLabelMouseClicked(evt);
            }
        });

        _cookiesMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _cookiesMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cookiesMinusLabel.setForeground(java.awt.Color.white);
        _cookiesMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cookiesMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _cookiesMinusLabel.setOpaque(true);
        _cookiesMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _cookiesMinusLabelMouseClicked(evt);
            }
        });

        _chunkyLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chunky-monkey.png"))); // NOI18N
        _chunkyLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _chunkyLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _chunkyLabelMouseEntered(evt);
            }
        });

        _chunkyNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _chunkyNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chunkyNumberLabel.setForeground(java.awt.Color.white);
        _chunkyNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chunkyNumberLabel.setText("2");
        _chunkyNumberLabel.setOpaque(true);

        _chunkyAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _chunkyAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chunkyAddLabel.setForeground(java.awt.Color.white);
        _chunkyAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chunkyAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _chunkyAddLabel.setOpaque(true);
        _chunkyAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _chunkyAddLabelMouseClicked(evt);
            }
        });

        _chunkyMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _chunkyMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chunkyMinusLabel.setForeground(java.awt.Color.white);
        _chunkyMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chunkyMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _chunkyMinusLabel.setOpaque(true);
        _chunkyMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _chunkyMinusLabelMouseClicked(evt);
            }
        });

        _vulcanoLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/vulcano.png"))); // NOI18N
        _vulcanoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _vulcanoLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _vulcanoLabelMouseEntered(evt);
            }
        });

        _vulcanoNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _vulcanoNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _vulcanoNumberLabel.setForeground(java.awt.Color.white);
        _vulcanoNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _vulcanoNumberLabel.setText("2");
        _vulcanoNumberLabel.setOpaque(true);

        _vulcanoAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _vulcanoAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _vulcanoAddLabel.setForeground(java.awt.Color.white);
        _vulcanoAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _vulcanoAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _vulcanoAddLabel.setOpaque(true);
        _vulcanoAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _vulcanoAddLabelMouseClicked(evt);
            }
        });

        _vulcanoMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _vulcanoMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _vulcanoMinusLabel.setForeground(java.awt.Color.white);
        _vulcanoMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _vulcanoMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _vulcanoMinusLabel.setOpaque(true);
        _vulcanoMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _vulcanoMinusLabelMouseClicked(evt);
            }
        });

        _chocolateLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chocolate-fudge-brownie.png"))); // NOI18N
        _chocolateLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _chocolateLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _chocolateLabelMouseEntered(evt);
            }
        });

        _chocolateNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _chocolateNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chocolateNumberLabel.setForeground(java.awt.Color.white);
        _chocolateNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chocolateNumberLabel.setText("2");
        _chocolateNumberLabel.setOpaque(true);

        _chocolateAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _chocolateAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chocolateAddLabel.setForeground(java.awt.Color.white);
        _chocolateAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chocolateAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _chocolateAddLabel.setOpaque(true);
        _chocolateAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _chocolateAddLabelMouseClicked(evt);
            }
        });

        _chocolateMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _chocolateMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chocolateMinusLabel.setForeground(java.awt.Color.white);
        _chocolateMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chocolateMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _chocolateMinusLabel.setOpaque(true);
        _chocolateMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _chocolateMinusLabelMouseClicked(evt);
            }
        });

        _caramelLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramel-chew-chew.png"))); // NOI18N
        _caramelLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _caramelLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _caramelLabelMouseEntered(evt);
            }
        });

        _caramelNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _caramelNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _caramelNumberLabel.setForeground(java.awt.Color.white);
        _caramelNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _caramelNumberLabel.setText("2");
        _caramelNumberLabel.setOpaque(true);

        _caramelAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _caramelAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _caramelAddLabel.setForeground(java.awt.Color.white);
        _caramelAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _caramelAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _caramelAddLabel.setOpaque(true);
        _caramelAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _caramelAddLabelMouseClicked(evt);
            }
        });

        _caramelMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _caramelMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _caramelMinusLabel.setForeground(java.awt.Color.white);
        _caramelMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _caramelMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _caramelMinusLabel.setOpaque(true);
        _caramelMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _caramelMinusLabelMouseClicked(evt);
            }
        });

        _brownieLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/brownie.png"))); // NOI18N
        _brownieLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _brownieLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _brownieLabelMouseEntered(evt);
            }
        });

        _brownieNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _brownieNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _brownieNumberLabel.setForeground(java.awt.Color.white);
        _brownieNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _brownieNumberLabel.setText("2");
        _brownieNumberLabel.setOpaque(true);

        _brownieAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _brownieAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _brownieAddLabel.setForeground(java.awt.Color.white);
        _brownieAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _brownieAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _brownieAddLabel.setOpaque(true);
        _brownieAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _brownieAddLabelMouseClicked(evt);
            }
        });

        _brownieMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _brownieMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _brownieMinusLabel.setForeground(java.awt.Color.white);
        _brownieMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _brownieMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _brownieMinusLabel.setOpaque(true);
        _brownieMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _brownieMinusLabelMouseClicked(evt);
            }
        });

        _trufflesLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/truffles.png"))); // NOI18N
        _trufflesLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                _trufflesLabelMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                _trufflesLabelMouseEntered(evt);
            }
        });

        _trufflesNumberLabel.setBackground(new java.awt.Color(0, 85, 159));
        _trufflesNumberLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _trufflesNumberLabel.setForeground(java.awt.Color.white);
        _trufflesNumberLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _trufflesNumberLabel.setText("2");
        _trufflesNumberLabel.setOpaque(true);

        _trufflesAddLabel.setBackground(new java.awt.Color(150, 179, 48));
        _trufflesAddLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _trufflesAddLabel.setForeground(java.awt.Color.white);
        _trufflesAddLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _trufflesAddLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/add.png"))); // NOI18N
        _trufflesAddLabel.setOpaque(true);
        _trufflesAddLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _trufflesAddLabelMouseClicked(evt);
            }
        });

        _trufflesMinusLabel.setBackground(new java.awt.Color(223, 30, 60));
        _trufflesMinusLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _trufflesMinusLabel.setForeground(java.awt.Color.white);
        _trufflesMinusLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _trufflesMinusLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/minus.png"))); // NOI18N
        _trufflesMinusLabel.setOpaque(true);
        _trufflesMinusLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                _trufflesMinusLabelMouseClicked(evt);
            }
        });

        _strawberryTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _strawberryTittleLabel.setForeground(java.awt.Color.white);
        _strawberryTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _strawberryTittleLabel.setText("Tarta de queso");

        _doughTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _doughTittleLabel.setForeground(java.awt.Color.white);
        _doughTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _doughTittleLabel.setText("Galleta");

        _chocolateTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chocolateTittleLabel.setForeground(java.awt.Color.white);
        _chocolateTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chocolateTittleLabel.setText("Chocolate");

        _chunkyTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _chunkyTittleLabel.setForeground(java.awt.Color.white);
        _chunkyTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _chunkyTittleLabel.setText("Mono Fornido");

        _appleTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _appleTittleLabel.setForeground(java.awt.Color.white);
        _appleTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _appleTittleLabel.setText("La D Manzana");

        _cookiesTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _cookiesTittleLabel.setForeground(java.awt.Color.white);
        _cookiesTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _cookiesTittleLabel.setText("Cookies");

        _vulcanoTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _vulcanoTittleLabel.setForeground(java.awt.Color.white);
        _vulcanoTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _vulcanoTittleLabel.setText("Vulcano");

        _brownieTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _brownieTittleLabel.setForeground(java.awt.Color.white);
        _brownieTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _brownieTittleLabel.setText("Brownie");

        _trufflesTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _trufflesTittleLabel.setForeground(java.awt.Color.white);
        _trufflesTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _trufflesTittleLabel.setText("Trufas");

        _caramelTittleLabel.setFont(new java.awt.Font("FreeSans", 1, 18)); // NOI18N
        _caramelTittleLabel.setForeground(java.awt.Color.white);
        _caramelTittleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        _caramelTittleLabel.setText("Caramelo");

        javax.swing.GroupLayout _dessertsCardLayout = new javax.swing.GroupLayout(_dessertsCard);
        _dessertsCard.setLayout(_dessertsCardLayout);
        _dessertsCardLayout.setHorizontalGroup(
            _dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_dessertsCardLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(_strawberryMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_strawberryNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_strawberryAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_doughMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_doughNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_doughAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_chunkyMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_chunkyNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_chunkyAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_chocolateMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_chocolateNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_chocolateAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_caramelMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_caramelNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_caramelAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(_dessertsCardLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(_appleTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(_cookiesTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(_vulcanoTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(_brownieTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(_trufflesTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(_dessertsCardLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(_appleLabel)
                .addGap(26, 26, 26)
                .addComponent(_cookiesLabel)
                .addGap(26, 26, 26)
                .addComponent(_vulcanoLabel)
                .addGap(26, 26, 26)
                .addComponent(_brownieLabel)
                .addGap(26, 26, 26)
                .addComponent(_trufflesLabel))
            .addGroup(_dessertsCardLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(_appleMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_appleNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_appleAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_cookiesMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_cookiesNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_cookiesAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_vulcanoMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_vulcanoNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_vulcanoAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_brownieMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_brownieNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_brownieAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(_trufflesMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_trufflesNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(_trufflesAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(_dessertsCardLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(_dessertsCardLayout.createSequentialGroup()
                        .addComponent(_strawberryLabel)
                        .addGap(26, 26, 26)
                        .addComponent(_doughLabel)
                        .addGap(26, 26, 26)
                        .addComponent(_chunkyLabel))
                    .addGroup(_dessertsCardLayout.createSequentialGroup()
                        .addComponent(_strawberryTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(_doughTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(_chunkyTittleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(_chocolateTittleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(_chocolateLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(26, 26, 26)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_caramelLabel)
                    .addComponent(_caramelTittleLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        _dessertsCardLayout.setVerticalGroup(
            _dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(_dessertsCardLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_strawberryTittleLabel)
                    .addComponent(_doughTittleLabel)
                    .addComponent(_chunkyTittleLabel)
                    .addComponent(_chocolateTittleLabel)
                    .addComponent(_caramelTittleLabel))
                .addGap(6, 6, 6)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_strawberryLabel)
                    .addComponent(_doughLabel)
                    .addComponent(_chunkyLabel)
                    .addComponent(_chocolateLabel)
                    .addComponent(_caramelLabel))
                .addGap(6, 6, 6)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_strawberryMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_strawberryNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_strawberryAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_doughMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_doughNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_doughAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chunkyMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chunkyNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chunkyAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chocolateMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chocolateNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_chocolateAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_caramelMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_caramelNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_caramelAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_appleTittleLabel)
                    .addComponent(_cookiesTittleLabel)
                    .addComponent(_vulcanoTittleLabel)
                    .addComponent(_brownieTittleLabel)
                    .addComponent(_trufflesTittleLabel))
                .addGap(6, 6, 6)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_appleLabel)
                    .addComponent(_cookiesLabel)
                    .addComponent(_vulcanoLabel)
                    .addComponent(_brownieLabel)
                    .addComponent(_trufflesLabel))
                .addGap(6, 6, 6)
                .addGroup(_dessertsCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(_appleMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_appleNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_appleAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_cookiesMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_cookiesNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_cookiesAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_vulcanoMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_vulcanoNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_vulcanoAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_brownieMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_brownieNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_brownieAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_trufflesMinusLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_trufflesNumberLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(_trufflesAddLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        _cardsPanel.add(_dessertsCard, "card2");

        _headCard.add(_cardsPanel);
        _cardsPanel.setBounds(0, 80, 1120, 620);

        _parentPanel.add(_headCard, "card3");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(_parentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(_parentPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void _startLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__startLabelMouseClicked
        _parentPanel.removeAll();
        _parentPanel.add(_headCard);
        _parentPanel.repaint();
        _parentPanel.revalidate();
    }//GEN-LAST:event__startLabelMouseClicked

    private void _orderPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__orderPanelMouseClicked
        _sodaCardboardLabel.setVisible(!_sodaCardboardLabel.isVisible());
        if (_isSquirted) {
            _sodaAddLabel.setVisible(_itemsPanel.isVisible());
            _sodaMinusLabel.setVisible(_itemsPanel.isVisible());
            _sodaNumberLabel.setVisible(_itemsPanel.isVisible());
            _sodaTrashLabel.setVisible(_itemsPanel.isVisible());
        } else {
            _sodaAddLabel.setVisible(false);
            _sodaMinusLabel.setVisible(false);
            _sodaNumberLabel.setVisible(false);
            _sodaTrashLabel.setVisible(false);
        }
        _itemsPanel.setVisible(!_itemsPanel.isVisible());
        _confirmPanel.setVisible(!_confirmPanel.isVisible());
        _confirmLabel.setVisible(!_confirmLabel.isVisible());
        _caramelLabel.setVisible(!_caramelLabel.isVisible());
        _trufflesLabel.setVisible(!_trufflesLabel.isVisible());
        _caramelAddLabel.setVisible(!_caramelAddLabel.isVisible());
        _trufflesAddLabel.setVisible(!_trufflesAddLabel.isVisible());
        _caramelMinusLabel.setVisible(!_caramelMinusLabel.isVisible());
        _trufflesMinusLabel.setVisible(!_trufflesMinusLabel.isVisible());
        _caramelNumberLabel.setVisible(!_caramelNumberLabel.isVisible());
        _trufflesNumberLabel.setVisible(!_trufflesNumberLabel.isVisible());
        _chocolateTittleLabel.setVisible(!_chocolateTittleLabel.isVisible());
        _brownieTittleLabel.setVisible(!_brownieTittleLabel.isVisible());
        _dessertsLabel.setVisible(!_dessertsLabel.isVisible());
        _dessertsIconLabel.setVisible(!_dessertsIconLabel.isVisible());
        _breadLabel.setVisible(!_breadLabel.isVisible());
        _breadAddLabel.setVisible(!_breadAddLabel.isVisible());
        _breadMinusLabel.setVisible(!_breadMinusLabel.isVisible());
        _breadNumberLabel.setVisible(!_breadNumberLabel.isVisible());
        _potatoesLabel.setVisible(!_potatoesLabel.isVisible());
        _potatoesAddLabel.setVisible(!_potatoesAddLabel.isVisible());
        _potatoesMinusLabel.setVisible(!_potatoesMinusLabel.isVisible());
        _potatoesNumberLabel.setVisible(!_potatoesNumberLabel.isVisible());
        
        _oliveLabel.setVisible(!_itemsPanel.isVisible());
        _anchovyLabel.setVisible(!_itemsPanel.isVisible());
        _tunaLabel.setVisible(!_itemsPanel.isVisible());
        _baconLabel.setVisible(!_itemsPanel.isVisible());
        _onionLabel.setVisible(!_itemsPanel.isVisible());
        _mushroomLabel.setVisible(!_itemsPanel.isVisible());
        _yorkLabel.setVisible(!_itemsPanel.isVisible());
        _hamLabel.setVisible(!_itemsPanel.isVisible());
        _cornLabel.setVisible(!_itemsPanel.isVisible());
        _pepperoniLabel.setVisible(!_itemsPanel.isVisible());
        _pepperLabel.setVisible(!_itemsPanel.isVisible());
        _pineappleLabel.setVisible(!_itemsPanel.isVisible());
        _pizzaChickenLabel.setVisible(!_itemsPanel.isVisible());
        _beefLabel.setVisible(!_itemsPanel.isVisible());
        _tomateLabel.setVisible(!_itemsPanel.isVisible());
        _caramelPizzaLabel.setVisible(!_itemsPanel.isVisible());
        
        if (_currentPizza != -1) {
            _tickOliveLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isOlives());
            _tickAnchovyLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isAnchovies());
            _tickTunaLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isTuna());
            _tickBaconLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isBacon());
            _tickOnionLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isOnion());
            _tickMushroomLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isMushrooms());
            _tickYorkLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isYork());
            _tickHamLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isHam());
            _tickCornLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isCorn());
            _tickPepperoniLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isPepperoni());
            _tickPepperLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isPepper());
            _tickPineappleLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isPineapple());
            _tickChickenLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isChicken());
            _tickBeefLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isBeef());
            _tickTomatoeLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isTomato());
            _tickCaramelLabel.setVisible(!_itemsPanel.isVisible() && _pizzas.get(_currentPizza).isCaramel());
        }
        
        _previousLabel.setVisible(!_itemsPanel.isVisible() && _currentPizza != 0 && _nPizzas > 1);
        
        
        if(_itemsPanel.isVisible()) {
            _orderPanel.setBackground(new java.awt.Color(199, 26, 54));
            _itemsPanel.removeAll();
            double totalPrice = 0;
            JLabel total = new JLabel();
            total.setVisible(false);
            
            JLabel pizzas = new JLabel();
            pizzas.setText("PIZZAS");
            pizzas.setVisible(false);
            pizzas.setFont(_tittleLabel.getFont());
            pizzas.setForeground(_tittleLabel.getForeground());
            pizzas.setHorizontalAlignment(_tittleLabel.getHorizontalAlignment());
            pizzas.setPreferredSize(_tittleLabel.getPreferredSize());
            
            _itemsPanel.add(pizzas);
            
            for (int i = 0; i < _nPizzas; i++) {
                pizzas.setVisible(true);
                total.setVisible(true);
                JLabel pizza = new JLabel();
                pizza.setText(String.valueOf(_pizzas.get(i).getNumber()));
                pizza.setFont(_itemNumberLabel.getFont());
                pizza.setForeground(_itemNumberLabel.getForeground());
                pizza.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(pizza);
                pizza = new JLabel();
                pizza.setText(_pizzas.get(i).getName());
                pizza.setFont(_itemNameLabel.getFont());
                pizza.setForeground(_itemNameLabel.getForeground());
                pizza.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(pizza);
                pizza = new JLabel();
                pizza.setText(String.valueOf(7.35 + _pizzas.get(i).getSize()*3) + " €");
                totalPrice += 7.35 + _pizzas.get(i).getSize()*3;
                pizza.setFont(_itemPriceLabel.getFont());
                pizza.setForeground(_itemPriceLabel.getForeground());
                pizza.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(pizza);
            }
            
            JLabel drinks = new JLabel();
            drinks.setText("BEBIDAS");
            drinks.setVisible(false);
            drinks.setFont(_tittleLabel.getFont());
            drinks.setForeground(_tittleLabel.getForeground());
            drinks.setHorizontalAlignment(_tittleLabel.getHorizontalAlignment());
            drinks.setPreferredSize(_tittleLabel.getPreferredSize());
            _itemsPanel.add(drinks);
            
            if (Integer.valueOf(_pepsiNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_pepsiNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("Pepsi");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_pepsiNumberLabel.getText())*2.20) + " €");
                totalPrice += Integer.valueOf(_pepsiNumberLabel.getText())*2.20;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            if (Integer.valueOf(_lightNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_lightNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("Pepsi Light");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_lightNumberLabel.getText())*2.20) + " €");
                totalPrice += Integer.valueOf(_lightNumberLabel.getText())*2.20;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            if (Integer.valueOf(_orangeNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_orangeNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("KAS naranja");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_orangeNumberLabel.getText())*2.20) + " €");
                totalPrice += Integer.valueOf(_orangeNumberLabel.getText())*2.20;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            if (Integer.valueOf(_lemonNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_lemonNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("KAS limón");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_lemonNumberLabel.getText())*2.20) + " €");
                totalPrice += Integer.valueOf(_lemonNumberLabel.getText())*2.20;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            if (Integer.valueOf(_zeroNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_zeroNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("Pepsi zero");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_zeroNumberLabel.getText())*2.20) + " €");
                totalPrice += Integer.valueOf(_zeroNumberLabel.getText())*2.20;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            if (Integer.valueOf(_waterNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_waterNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("Botella agua");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_waterNumberLabel.getText())*1.50) + " €");
                totalPrice += Integer.valueOf(_waterNumberLabel.getText())*1.50;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            if (Integer.valueOf(_redBullNumberLabel.getText()) != 0) {
                drinks.setVisible(true);
                total.setVisible(true);
                JLabel drink = new JLabel();
                drink.setText(_redBullNumberLabel.getText());
                drink.setFont(_itemNumberLabel.getFont());
                drink.setForeground(_itemNumberLabel.getForeground());
                drink.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText("Red Bull");
                drink.setFont(_itemNameLabel.getFont());
                drink.setForeground(_itemNameLabel.getForeground());
                drink.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(drink);
                drink = new JLabel();
                drink.setText(String.valueOf(Integer.valueOf(_redBullNumberLabel.getText())*2.70) + " €");
                totalPrice += Integer.valueOf(_redBullNumberLabel.getText())*2.20;
                drink.setFont(_itemPriceLabel.getFont());
                drink.setForeground(_itemPriceLabel.getForeground());
                drink.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(drink);
            }
            
            JLabel snacks = new JLabel();
            snacks.setText("ENTRANTES");
            snacks.setVisible(false);
            snacks.setFont(_tittleLabel.getFont());
            snacks.setForeground(_tittleLabel.getForeground());
            snacks.setHorizontalAlignment(_tittleLabel.getHorizontalAlignment());
            snacks.setPreferredSize(_tittleLabel.getPreferredSize());
            _itemsPanel.add(snacks);
            
            
            if (Integer.valueOf(_chickenNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_chickenNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_chickenTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_chickenNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_chickenNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_wingNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_wingNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_wingTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_wingNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_wingNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_cheeseBreadNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_cheeseBreadNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_cheeseBreadTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_cheeseBreadNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_cheeseBreadNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_breadNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_breadNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_breadTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_breadNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_breadNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_kickersNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_kickersNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_kickersTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_kickersNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_kickersNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_wingsNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_wingsNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_wingsTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_wingsNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_wingsNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_strippersNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_strippersNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_strippersTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_strippersNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_strippersNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            if (Integer.valueOf(_potatoesNumberLabel.getText()) != 0) {
                snacks.setVisible(true);
                total.setVisible(true);
                JLabel snack = new JLabel();
                snack.setText(_potatoesNumberLabel.getText());
                snack.setFont(_itemNumberLabel.getFont());
                snack.setForeground(_itemNumberLabel.getForeground());
                snack.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(_potatoesTittleLabel.getText());
                snack.setFont(_itemNameLabel.getFont());
                snack.setForeground(_itemNameLabel.getForeground());
                snack.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(snack);
                snack = new JLabel();
                snack.setText(String.valueOf(Integer.valueOf(_potatoesNumberLabel.getText())*3.7) + " €");
                totalPrice += Integer.valueOf(_potatoesNumberLabel.getText())*3.7;
                snack.setFont(_itemPriceLabel.getFont());
                snack.setForeground(_itemPriceLabel.getForeground());
                snack.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(snack);
            }
            
            
            
            JLabel desserts = new JLabel();
            desserts.setText("POSTRES");
            desserts.setVisible(false);
            desserts.setFont(_tittleLabel.getFont());
            desserts.setForeground(_tittleLabel.getForeground());
            desserts.setHorizontalAlignment(_tittleLabel.getHorizontalAlignment());
            desserts.setPreferredSize(_tittleLabel.getPreferredSize());
            _itemsPanel.add(desserts);
            
            if (Integer.valueOf(_strawberryNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_strawberryNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_strawberryTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_strawberryNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_strawberryNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_doughNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_doughNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_doughTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_doughNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_doughNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_chunkyNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_chunkyNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_chunkyTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_chunkyNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_chunkyNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_chocolateNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_chocolateNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_chocolateTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_chocolateNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_chocolateNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_caramelNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_caramelNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_caramelTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_caramelNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_caramelNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_appleNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_appleNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_appleTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_appleNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_appleNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_cookiesNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_cookiesNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_cookiesTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_cookiesNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_cookiesNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_vulcanoNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_vulcanoNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_vulcanoTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_vulcanoNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_vulcanoNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_brownieNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_brownieNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_brownieTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_brownieNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_brownieNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            if (Integer.valueOf(_trufflesNumberLabel.getText()) != 0) {
                desserts.setVisible(true);
                total.setVisible(true);
                JLabel dessert = new JLabel();
                dessert.setText(_trufflesNumberLabel.getText());
                dessert.setFont(_itemNumberLabel.getFont());
                dessert.setForeground(_itemNumberLabel.getForeground());
                dessert.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(_trufflesTittleLabel.getText());
                dessert.setFont(_itemNameLabel.getFont());
                dessert.setForeground(_itemNameLabel.getForeground());
                dessert.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(dessert);
                dessert = new JLabel();
                dessert.setText(String.valueOf(Integer.valueOf(_trufflesNumberLabel.getText())*3.5) + " €");
                totalPrice += Integer.valueOf(_trufflesNumberLabel.getText())*3.5;
                dessert.setFont(_itemPriceLabel.getFont());
                dessert.setForeground(_itemPriceLabel.getForeground());
                dessert.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(dessert);
            }
            
            total.setText("TOTAL");
            total.setFont(_tittleLabel.getFont());
            total.setForeground(_tittleLabel.getForeground());
            total.setHorizontalAlignment(_tittleLabel.getHorizontalAlignment());
            total.setPreferredSize(_tittleLabel.getPreferredSize());
            _itemsPanel.add(total);
            
            if(total.isVisible()) {
                JLabel price = new JLabel();
                price.setText("");
                price.setFont(_itemNumberLabel.getFont());
                price.setForeground(_itemNumberLabel.getForeground());
                price.setPreferredSize(_itemNumberLabel.getPreferredSize());
                _itemsPanel.add(price);
                price = new JLabel();
                price.setText("");
                price.setFont(_itemNameLabel.getFont());
                price.setForeground(_itemNameLabel.getForeground());
                price.setPreferredSize(_itemNameLabel.getPreferredSize());
                _itemsPanel.add(price);
                price = new JLabel();
                price.setText(String.valueOf(totalPrice) + " €");
                price.setFont(_itemPriceLabel.getFont());
                price.setForeground(_itemPriceLabel.getForeground());
                price.setPreferredSize(_itemPriceLabel.getPreferredSize());
                _itemsPanel.add(price);
                _itemsPanel.add(_confirmPanel);
            }
            
            
        } else {
            _orderPanel.setBackground(new java.awt.Color(223, 30, 60));
        }
    }//GEN-LAST:event__orderPanelMouseClicked

    private void _confirmPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__confirmPanelMouseClicked

        JFrame dominosOrder = new DominosOrder();
        dominosOrder.setVisible(true);
        this.dispose();
    }//GEN-LAST:event__confirmPanelMouseClicked

    private void _drinksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__drinksMouseClicked

        _backLabel.setVisible(true);
        _cardsPanel.removeAll();
        _cardsPanel.add(_drinksCard);
        _cardsPanel.repaint();
        _cardsPanel.revalidate();
    }//GEN-LAST:event__drinksMouseClicked

    private void _pepsiLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepsiLabelMouseClicked
        if (!_isSquirted && _isPepsi && !_itemsPanel.isVisible()) {
            _isSquirted = true;
            _pepsiSquirtLabel.setVisible(true);
            for (int i = 0; i < 110; i++) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
                _pepsiSquirtLabel.paintImmediately(0, 0, 120, i);
            }
            try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
            _sodaCardboardLabel.setIcon((new javax.swing.ImageIcon(getClass().getResource("/img/pepsi.png"))));
            _pepsiSquirtLabel.setVisible(false);
            _sodaMinusLabel.setLocation(24, _sodaMinusLabel.getLocation().y);
            _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaMinusLabel.setVisible(true);
            _sodaNumberLabel.setVisible(true);
            _sodaAddLabel.setVisible(true);
            _pepsiNumberLabel.setText(String.valueOf(Integer.valueOf(_pepsiNumberLabel.getText())+1));
            _sodaNumberLabel.setText(_pepsiNumberLabel.getText());
            _sodaTrashLabel.setVisible(true);
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        }
    }//GEN-LAST:event__pepsiLabelMouseClicked

    private void _lightLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lightLabelMouseClicked
        if (!_isSquirted && _isLight && !_itemsPanel.isVisible()) {
            _isSquirted = true;
            _lightSquirtLabel.setVisible(true);
            for (int i = 0; i < 110; i++) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
                _lightSquirtLabel.paintImmediately(0, 0, 120, i);
            }
            try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
            _sodaCardboardLabel.setIcon((new javax.swing.ImageIcon(getClass().getResource("/img/pepsi.png"))));
            _lightSquirtLabel.setVisible(false);
            _sodaMinusLabel.setLocation(198, _sodaMinusLabel.getLocation().y);
            _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaMinusLabel.setVisible(true);
            _sodaNumberLabel.setVisible(true);
            _sodaAddLabel.setVisible(true);
            _lightNumberLabel.setText(String.valueOf(Integer.valueOf(_lightNumberLabel.getText())+1));
            _sodaNumberLabel.setText(_lightNumberLabel.getText());
            _sodaTrashLabel.setVisible(true);
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        }
    }//GEN-LAST:event__lightLabelMouseClicked

    private void _orangeLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__orangeLabelMouseClicked
        if (!_isSquirted && _isOrange && !_itemsPanel.isVisible()) {
            _isSquirted = true;
            _orangeSquirtLabel.setVisible(true);
            for (int i = 0; i < 110; i++) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
                _orangeSquirtLabel.paintImmediately(0, 0, 120, i);
            }
            try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
            _sodaCardboardLabel.setIcon((new javax.swing.ImageIcon(getClass().getResource("/img/orange.png"))));
            _orangeSquirtLabel.setVisible(false);
            _sodaMinusLabel.setLocation(372, _sodaMinusLabel.getLocation().y);
            _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaMinusLabel.setVisible(true);
            _sodaNumberLabel.setVisible(true);
            _sodaAddLabel.setVisible(true);
            _orangeNumberLabel.setText(String.valueOf(Integer.valueOf(_orangeNumberLabel.getText())+1));
            _sodaNumberLabel.setText(_orangeNumberLabel.getText());
            _sodaTrashLabel.setVisible(true);
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        }
    }//GEN-LAST:event__orangeLabelMouseClicked

    private void _lemonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lemonLabelMouseClicked
        if (!_isSquirted && _isLemon && !_itemsPanel.isVisible()) {
            _isSquirted = true;
            _lemonSquirtLabel.setVisible(true);
            for (int i = 0; i < 110; i++) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
                _lemonSquirtLabel.paintImmediately(0, 0, 120, i);
            }
            try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
            _sodaCardboardLabel.setIcon((new javax.swing.ImageIcon(getClass().getResource("/img/lemon.png"))));
            _lemonSquirtLabel.setVisible(false);
            _sodaMinusLabel.setLocation(546, _sodaMinusLabel.getLocation().y);
            _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaMinusLabel.setVisible(true);
            _sodaNumberLabel.setVisible(true);
            _sodaAddLabel.setVisible(true);
            _lemonNumberLabel.setText(String.valueOf(Integer.valueOf(_lemonNumberLabel.getText())+1));
            _sodaNumberLabel.setText(_lemonNumberLabel.getText());
            _sodaTrashLabel.setVisible(true);
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        }
    }//GEN-LAST:event__lemonLabelMouseClicked

    private void _zeroLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__zeroLabelMouseClicked
        if (!_isSquirted && _isZero && !_itemsPanel.isVisible()) {
            _isSquirted = true;
            _zeroSquirtLabel.setVisible(true);
            for (int i = 0; i < 110; i++) {
                try {
                    Thread.sleep(1);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
                _zeroSquirtLabel.paintImmediately(0, 0, 120, i);
            }
            try {
                    Thread.sleep(3000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(DominosOrder.class.getName()).log(Level.SEVERE, null, ex);
                }
            _sodaCardboardLabel.setIcon((new javax.swing.ImageIcon(getClass().getResource("/img/pepsi.png"))));
            _zeroSquirtLabel.setVisible(false);
            _sodaMinusLabel.setLocation(720, _sodaMinusLabel.getLocation().y);
            _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
            _sodaMinusLabel.setVisible(true);
            _sodaNumberLabel.setVisible(true);
            _sodaAddLabel.setVisible(true);
            _zeroNumberLabel.setText(String.valueOf(Integer.valueOf(_zeroNumberLabel.getText())+1));
            _sodaNumberLabel.setText(_zeroNumberLabel.getText());
            _sodaTrashLabel.setVisible(true);
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        }
    }//GEN-LAST:event__zeroLabelMouseClicked

    private void _dessertsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__dessertsMouseClicked

        _backLabel.setVisible(true);
        _cardsPanel.removeAll();
        _cardsPanel.add(_dessertsCard);
        _cardsPanel.repaint();
        _cardsPanel.revalidate();
    }//GEN-LAST:event__dessertsMouseClicked

    private void _strawberryAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strawberryAddLabelMouseClicked
        _strawberryNumberLabel.setText(String.valueOf(Integer.valueOf(_strawberryNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__strawberryAddLabelMouseClicked

    private void _doughAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__doughAddLabelMouseClicked
        _doughNumberLabel.setText(String.valueOf(Integer.valueOf(_doughNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__doughAddLabelMouseClicked

    private void _chunkyAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chunkyAddLabelMouseClicked
        _chunkyNumberLabel.setText(String.valueOf(Integer.valueOf(_chunkyNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__chunkyAddLabelMouseClicked

    private void _chocolateAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chocolateAddLabelMouseClicked
        _chocolateNumberLabel.setText(String.valueOf(Integer.valueOf(_chocolateNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__chocolateAddLabelMouseClicked

    private void _caramelAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelAddLabelMouseClicked
        _caramelNumberLabel.setText(String.valueOf(Integer.valueOf(_caramelNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__caramelAddLabelMouseClicked

    private void _appleAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__appleAddLabelMouseClicked
        _appleNumberLabel.setText(String.valueOf(Integer.valueOf(_appleNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__appleAddLabelMouseClicked

    private void _cookiesAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cookiesAddLabelMouseClicked
        _cookiesNumberLabel.setText(String.valueOf(Integer.valueOf(_cookiesNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__cookiesAddLabelMouseClicked

    private void _vulcanoAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__vulcanoAddLabelMouseClicked
        _vulcanoNumberLabel.setText(String.valueOf(Integer.valueOf(_vulcanoNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__vulcanoAddLabelMouseClicked

    private void _brownieAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__brownieAddLabelMouseClicked
        _brownieNumberLabel.setText(String.valueOf(Integer.valueOf(_brownieNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__brownieAddLabelMouseClicked

    private void _trufflesAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__trufflesAddLabelMouseClicked
        _trufflesNumberLabel.setText(String.valueOf(Integer.valueOf(_trufflesNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__trufflesAddLabelMouseClicked

    private void _strawberryMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strawberryMinusLabelMouseClicked
        if (Integer.valueOf(_strawberryNumberLabel.getText()) != 0) {
            _strawberryNumberLabel.setText(String.valueOf(Integer.valueOf(_strawberryNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__strawberryMinusLabelMouseClicked

    private void _doughMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__doughMinusLabelMouseClicked
        if (Integer.valueOf(_doughNumberLabel.getText()) != 0) {
            _doughNumberLabel.setText(String.valueOf(Integer.valueOf(_doughNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__doughMinusLabelMouseClicked

    private void _chunkyMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chunkyMinusLabelMouseClicked
        if (Integer.valueOf(_chunkyNumberLabel.getText()) != 0) {
            _chunkyNumberLabel.setText(String.valueOf(Integer.valueOf(_chunkyNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__chunkyMinusLabelMouseClicked

    private void _chocolateMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chocolateMinusLabelMouseClicked
        if (Integer.valueOf(_chocolateNumberLabel.getText()) != 0) {
            _chocolateNumberLabel.setText(String.valueOf(Integer.valueOf(_chocolateNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__chocolateMinusLabelMouseClicked

    private void _caramelMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelMinusLabelMouseClicked
        if (Integer.valueOf(_caramelNumberLabel.getText()) != 0) {
            _caramelNumberLabel.setText(String.valueOf(Integer.valueOf(_caramelNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__caramelMinusLabelMouseClicked

    private void _appleMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__appleMinusLabelMouseClicked
        if (Integer.valueOf(_appleNumberLabel.getText()) != 0) {
            _appleNumberLabel.setText(String.valueOf(Integer.valueOf(_appleNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__appleMinusLabelMouseClicked

    private void _cookiesMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cookiesMinusLabelMouseClicked
        if (Integer.valueOf(_cookiesNumberLabel.getText()) != 0) {
            _cookiesNumberLabel.setText(String.valueOf(Integer.valueOf(_cookiesNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__cookiesMinusLabelMouseClicked

    private void _vulcanoMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__vulcanoMinusLabelMouseClicked
        if (Integer.valueOf(_vulcanoNumberLabel.getText()) != 0) {
            _vulcanoNumberLabel.setText(String.valueOf(Integer.valueOf(_vulcanoNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__vulcanoMinusLabelMouseClicked

    private void _brownieMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__brownieMinusLabelMouseClicked
        if (Integer.valueOf(_brownieNumberLabel.getText()) != 0) {
            _brownieNumberLabel.setText(String.valueOf(Integer.valueOf(_brownieNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__brownieMinusLabelMouseClicked

    private void _trufflesMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__trufflesMinusLabelMouseClicked
        if (Integer.valueOf(_trufflesNumberLabel.getText()) != 0) {
            _trufflesNumberLabel.setText(String.valueOf(Integer.valueOf(_trufflesNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__trufflesMinusLabelMouseClicked

    private void _strawberryLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strawberryLabelMouseEntered
        _strawberryTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__strawberryLabelMouseEntered

    private void _doughLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__doughLabelMouseEntered
        _doughTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__doughLabelMouseEntered

    private void _chunkyLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chunkyLabelMouseEntered
        _chunkyTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__chunkyLabelMouseEntered

    private void _chocolateLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chocolateLabelMouseEntered
        _chocolateTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__chocolateLabelMouseEntered

    private void _caramelLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelLabelMouseEntered
        _caramelTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__caramelLabelMouseEntered

    private void _appleLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__appleLabelMouseEntered
        _appleTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__appleLabelMouseEntered

    private void _cookiesLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cookiesLabelMouseEntered
        _cookiesTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__cookiesLabelMouseEntered

    private void _vulcanoLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__vulcanoLabelMouseEntered
        _vulcanoTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__vulcanoLabelMouseEntered

    private void _brownieLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__brownieLabelMouseEntered
        _brownieTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__brownieLabelMouseEntered

    private void _trufflesLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__trufflesLabelMouseEntered
        _trufflesTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__trufflesLabelMouseEntered

    private void _strawberryLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strawberryLabelMouseExited
        _strawberryTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__strawberryLabelMouseExited

    private void _doughLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__doughLabelMouseExited
        _doughTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__doughLabelMouseExited

    private void _chunkyLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chunkyLabelMouseExited
        _chunkyTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__chunkyLabelMouseExited

    private void _chocolateLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chocolateLabelMouseExited
        _chocolateTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__chocolateLabelMouseExited

    private void _caramelLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelLabelMouseExited
        _caramelTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__caramelLabelMouseExited

    private void _appleLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__appleLabelMouseExited
        _appleTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__appleLabelMouseExited

    private void _cookiesLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cookiesLabelMouseExited
        _cookiesTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__cookiesLabelMouseExited

    private void _vulcanoLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__vulcanoLabelMouseExited
        _vulcanoTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__vulcanoLabelMouseExited

    private void _brownieLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__brownieLabelMouseExited
        _brownieTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__brownieLabelMouseExited

    private void _trufflesLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__trufflesLabelMouseExited
        _trufflesTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__trufflesLabelMouseExited

    private void _potatoesLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__potatoesLabelMouseExited
        _potatoesTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__potatoesLabelMouseExited

    private void _potatoesLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__potatoesLabelMouseEntered
        _potatoesTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__potatoesLabelMouseEntered

    private void _potatoesAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__potatoesAddLabelMouseClicked
        _potatoesNumberLabel.setText(String.valueOf(Integer.valueOf(_potatoesNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__potatoesAddLabelMouseClicked

    private void _potatoesMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__potatoesMinusLabelMouseClicked
        if (Integer.valueOf(_potatoesNumberLabel.getText()) != 0) {
            _potatoesNumberLabel.setText(String.valueOf(Integer.valueOf(_potatoesNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__potatoesMinusLabelMouseClicked

    private void _chickenLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chickenLabelMouseExited
        _chickenTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__chickenLabelMouseExited

    private void _chickenLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chickenLabelMouseEntered
        _chickenTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__chickenLabelMouseEntered

    private void _chickenAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chickenAddLabelMouseClicked
        _chickenNumberLabel.setText(String.valueOf(Integer.valueOf(_chickenNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__chickenAddLabelMouseClicked

    private void _chickenMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__chickenMinusLabelMouseClicked
        if (Integer.valueOf(_chickenNumberLabel.getText()) != 0) {
            _chickenNumberLabel.setText(String.valueOf(Integer.valueOf(_chickenNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__chickenMinusLabelMouseClicked

    private void _kickersLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__kickersLabelMouseExited
        _kickersTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__kickersLabelMouseExited

    private void _kickersLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__kickersLabelMouseEntered
        _kickersTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__kickersLabelMouseEntered

    private void _kickersAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__kickersAddLabelMouseClicked
        _kickersNumberLabel.setText(String.valueOf(Integer.valueOf(_kickersNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__kickersAddLabelMouseClicked

    private void _kickersMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__kickersMinusLabelMouseClicked
        if (Integer.valueOf(_kickersNumberLabel.getText()) != 0) {
            _kickersNumberLabel.setText(String.valueOf(Integer.valueOf(_kickersNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__kickersMinusLabelMouseClicked

    private void _wingsLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingsLabelMouseExited
        _wingsTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__wingsLabelMouseExited

    private void _wingsLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingsLabelMouseEntered
        _wingsTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__wingsLabelMouseEntered

    private void _wingsAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingsAddLabelMouseClicked
        _wingsNumberLabel.setText(String.valueOf(Integer.valueOf(_wingsNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__wingsAddLabelMouseClicked

    private void _wingsMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingsMinusLabelMouseClicked
        if (Integer.valueOf(_wingsNumberLabel.getText()) != 0) {
            _wingsNumberLabel.setText(String.valueOf(Integer.valueOf(_wingsNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__wingsMinusLabelMouseClicked

    private void _wingLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingLabelMouseExited
        _wingTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__wingLabelMouseExited

    private void _wingLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingLabelMouseEntered
        _wingTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__wingLabelMouseEntered

    private void _wingAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingAddLabelMouseClicked
        _wingNumberLabel.setText(String.valueOf(Integer.valueOf(_wingNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__wingAddLabelMouseClicked

    private void _wingMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__wingMinusLabelMouseClicked
        if (Integer.valueOf(_wingNumberLabel.getText()) != 0) {
            _wingNumberLabel.setText(String.valueOf(Integer.valueOf(_wingNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__wingMinusLabelMouseClicked

    private void _cheeseBreadLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cheeseBreadLabelMouseExited
        _cheeseBreadTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__cheeseBreadLabelMouseExited

    private void _cheeseBreadLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cheeseBreadLabelMouseEntered
        _cheeseBreadTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__cheeseBreadLabelMouseEntered

    private void _cheeseBreadAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cheeseBreadAddLabelMouseClicked
        _cheeseBreadNumberLabel.setText(String.valueOf(Integer.valueOf(_cheeseBreadNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__cheeseBreadAddLabelMouseClicked

    private void _cheeseBreadMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cheeseBreadMinusLabelMouseClicked
        if (Integer.valueOf(_cheeseBreadNumberLabel.getText()) != 0) {
            _cheeseBreadNumberLabel.setText(String.valueOf(Integer.valueOf(_cheeseBreadNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__cheeseBreadMinusLabelMouseClicked

    private void _strippersLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strippersLabelMouseExited
        _strippersTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__strippersLabelMouseExited

    private void _strippersLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strippersLabelMouseEntered
        _strippersTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__strippersLabelMouseEntered

    private void _strippersAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strippersAddLabelMouseClicked
        _strippersNumberLabel.setText(String.valueOf(Integer.valueOf(_strippersNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__strippersAddLabelMouseClicked

    private void _strippersMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__strippersMinusLabelMouseClicked
        if (Integer.valueOf(_strippersNumberLabel.getText()) != 0) {
            _strippersNumberLabel.setText(String.valueOf(Integer.valueOf(_strippersNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__strippersMinusLabelMouseClicked

    private void _breadLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__breadLabelMouseExited
        _breadTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__breadLabelMouseExited

    private void _breadLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__breadLabelMouseEntered
        _breadTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__breadLabelMouseEntered

    private void _breadAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__breadAddLabelMouseClicked
        _breadNumberLabel.setText(String.valueOf(Integer.valueOf(_breadNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__breadAddLabelMouseClicked

    private void _breadMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__breadMinusLabelMouseClicked
        if (Integer.valueOf(_breadNumberLabel.getText()) != 0) {
            _breadNumberLabel.setText(String.valueOf(Integer.valueOf(_breadNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__breadMinusLabelMouseClicked

    private void _snacksMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__snacksMouseClicked

        _backLabel.setVisible(true);
        _cardsPanel.removeAll();
        _cardsPanel.add(_snacksCard);
        _cardsPanel.repaint();
        _cardsPanel.revalidate();
    }//GEN-LAST:event__snacksMouseClicked

    private void _waterLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__waterLabelMouseExited
        _waterTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__waterLabelMouseExited

    private void _waterLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__waterLabelMouseEntered
        _waterTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__waterLabelMouseEntered

    private void _waterAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__waterAddLabelMouseClicked
        _waterNumberLabel.setText(String.valueOf(Integer.valueOf(_waterNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__waterAddLabelMouseClicked

    private void _waterMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__waterMinusLabelMouseClicked
        if (Integer.valueOf(_waterNumberLabel.getText()) != 0) {
            _waterNumberLabel.setText(String.valueOf(Integer.valueOf(_waterNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__waterMinusLabelMouseClicked

    private void _redBullLabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__redBullLabelMouseExited
        _redBullTittleLabel.setForeground(new java.awt.Color(0, 98, 183));
    }//GEN-LAST:event__redBullLabelMouseExited

    private void _redBullLabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__redBullLabelMouseEntered
        _redBullTittleLabel.setForeground(Color.white);
    }//GEN-LAST:event__redBullLabelMouseEntered

    private void _redBullAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__redBullAddLabelMouseClicked
        _redBullNumberLabel.setText(String.valueOf(Integer.valueOf(_redBullNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
    }//GEN-LAST:event__redBullAddLabelMouseClicked

    private void _redBullMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__redBullMinusLabelMouseClicked
        if (Integer.valueOf(_redBullNumberLabel.getText()) != 0) {
            _redBullNumberLabel.setText(String.valueOf(Integer.valueOf(_redBullNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
    }//GEN-LAST:event__redBullMinusLabelMouseClicked

    private void _sodaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaLabelMouseClicked
        _drinksCardsPanel.removeAll();
        _drinksCardsPanel.add(_tapCard);
        _drinksCardsPanel.repaint();
        _drinksCardsPanel.revalidate();
    }//GEN-LAST:event__sodaLabelMouseClicked

    private void _beverageLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__beverageLabelMouseClicked
        _drinksCardsPanel.removeAll();
        _drinksCardsPanel.add(_beverageCard);
        _drinksCardsPanel.repaint();
        _drinksCardsPanel.revalidate();
    }//GEN-LAST:event__beverageLabelMouseClicked

    private void _sodaCardboardLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaCardboardLabelMouseDragged
        _sodaCardboardLabel.setLocation(_sodaCardboardLabel.getLocation().x + evt.getX() - _sodaCardboardLabel.getWidth()/2, _sodaCardboardLabel.getLocation().y + evt.getY() - _sodaCardboardLabel.getHeight()/2);
        if (_sodaCardboardLabel.getLocation().x + evt.getX() - _sodaCardboardLabel.getWidth()/2 < 48) {
            _sodaCardboardLabel.setLocation(48, _sodaCardboardLabel.getLocation().y);
        } else if (_sodaCardboardLabel.getLocation().x + evt.getX() - _sodaCardboardLabel.getWidth()/2 > 744) {
            _sodaCardboardLabel.setLocation(744, _sodaCardboardLabel.getLocation().y);
        }
        if (_sodaCardboardLabel.getLocation().y + evt.getY() - _sodaCardboardLabel.getHeight()/2 < 195) {
            _sodaCardboardLabel.setLocation(_sodaCardboardLabel.getLocation().x, 195);
        } else if (_sodaCardboardLabel.getLocation().y + evt.getY() - _sodaCardboardLabel.getHeight()/2 > 380) {
            _sodaCardboardLabel.setLocation(_sodaCardboardLabel.getLocation().x, 380);
        }
        _sodaMinusLabel.setLocation(_sodaCardboardLabel.getLocation().x - 24, _sodaCardboardLabel.getLocation().y + 210);
        _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
        _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
        _sodaTrashLabel.setLocation(_sodaAddLabel.getLocation().x, _sodaAddLabel.getLocation().y -60);
    }//GEN-LAST:event__sodaCardboardLabelMouseDragged

    private void _sodaCardboardLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaCardboardLabelMouseReleased
        if (_sodaCardboardLabel.getLocation().x + evt.getX() < 199) {
            _sodaCardboardLabel.setLocation(48, 280);
            if(!_isSquirted) {
                _isPepsi = true;
                _isLight = false;
                _isOrange = false;
                _isLemon = false;
                _isZero = false;
            }
        } else if (_sodaCardboardLabel.getLocation().x + evt.getX() < 373) {
            _sodaCardboardLabel.setLocation(222, 280);
            if(!_isSquirted) {
                _isPepsi = false;
                _isLight = true;
                _isOrange = false;
                _isLemon = false;
                _isZero = false;
            }
        } else if (_sodaCardboardLabel.getLocation().x + evt.getX() < 547) {
            _sodaCardboardLabel.setLocation(396, 280);
            if(!_isSquirted) {
                _isPepsi = false;
                _isLight = false;
                _isOrange = true;
                _isLemon = false;
                _isZero = false;
            }
        } else if (_sodaCardboardLabel.getLocation().x + evt.getX() < 712) {
            _sodaCardboardLabel.setLocation(570, 280);
            if(!_isSquirted) {
                _isPepsi = false;
                _isLight = false;
                _isOrange = false;
                _isLemon = true;
                _isZero = false;
            }
        } else {
            _sodaCardboardLabel.setLocation(744, 280);
            if(!_isSquirted) {
                _isPepsi = false;
                _isLight = false;
                _isOrange = false;
                _isLemon = false;
                _isZero = true;
            }
        }
        _sodaMinusLabel.setLocation(_sodaCardboardLabel.getLocation().x - 24, _sodaCardboardLabel.getLocation().y + 210);
        _sodaNumberLabel.setLocation(_sodaMinusLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
        _sodaAddLabel.setLocation(_sodaNumberLabel.getLocation().x + 60, _sodaMinusLabel.getLocation().y);
        _sodaTrashLabel.setLocation(_sodaAddLabel.getLocation().x, _sodaAddLabel.getLocation().y -60);
    }//GEN-LAST:event__sodaCardboardLabelMouseReleased

    private void _sodaMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaMinusLabelMouseClicked
        if (Integer.valueOf(_sodaNumberLabel.getText()) != 0) {
            if (_isPepsi) {
                _pepsiNumberLabel.setText(String.valueOf(Integer.valueOf(_pepsiNumberLabel.getText()) -1));
            } else if (_isLight) {
                _lightNumberLabel.setText(String.valueOf(Integer.valueOf(_lightNumberLabel.getText()) -1));
            } else if (_isOrange) {
                _orangeNumberLabel.setText(String.valueOf(Integer.valueOf(_orangeNumberLabel.getText()) -1));
            } else if (_isLemon) {
                _lemonNumberLabel.setText(String.valueOf(Integer.valueOf(_lemonNumberLabel.getText()) -1));
            } else if (_isZero) {
                _zeroNumberLabel.setText(String.valueOf(Integer.valueOf(_zeroNumberLabel.getText()) -1));
            }
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) -1));
        }
    }//GEN-LAST:event__sodaMinusLabelMouseClicked

    private void _sodaNumberLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaNumberLabelMouseClicked

    }//GEN-LAST:event__sodaNumberLabelMouseClicked

    private void _sodaAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaAddLabelMouseClicked
        if (_isPepsi) {
            _pepsiNumberLabel.setText(String.valueOf(Integer.valueOf(_pepsiNumberLabel.getText()) +1));
        } else if (_isLight) {
            _lightNumberLabel.setText(String.valueOf(Integer.valueOf(_lightNumberLabel.getText()) +1));
        } else if (_isOrange) {
            _orangeNumberLabel.setText(String.valueOf(Integer.valueOf(_orangeNumberLabel.getText()) +1));
        } else if (_isLemon) {
            _lemonNumberLabel.setText(String.valueOf(Integer.valueOf(_lemonNumberLabel.getText()) +1));
        } else if (_isZero) {
            _zeroNumberLabel.setText(String.valueOf(Integer.valueOf(_zeroNumberLabel.getText()) +1));
        }
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) +1));
    }//GEN-LAST:event__sodaAddLabelMouseClicked

    private void _pepsiAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepsiAddLabelMouseClicked
        _pepsiNumberLabel.setText(String.valueOf(Integer.valueOf(_pepsiNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        if (_isPepsi) {
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) +1));
        }
    }//GEN-LAST:event__pepsiAddLabelMouseClicked

    private void _pepsiNumberLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepsiNumberLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event__pepsiNumberLabelMouseClicked

    private void _pepsiMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepsiMinusLabelMouseClicked
        if (Integer.valueOf(_pepsiNumberLabel.getText()) != 0) {
            _pepsiNumberLabel.setText(String.valueOf(Integer.valueOf(_pepsiNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
            if (_isPepsi) {
                _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) -1));
            }
        }
    }//GEN-LAST:event__pepsiMinusLabelMouseClicked

    private void _lightMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lightMinusLabelMouseClicked
        if (Integer.valueOf(_lightNumberLabel.getText()) != 0) {
            _lightNumberLabel.setText(String.valueOf(Integer.valueOf(_lightNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        }
        if (_isLight) {
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) - 1));
        }
    }//GEN-LAST:event__lightMinusLabelMouseClicked

    private void _lightNumberLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lightNumberLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event__lightNumberLabelMouseClicked

    private void _lightAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lightAddLabelMouseClicked
        _lightNumberLabel.setText(String.valueOf(Integer.valueOf(_lightNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        if (_isLight) {
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) + 1));
        }
    }//GEN-LAST:event__lightAddLabelMouseClicked

    private void _orangeMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__orangeMinusLabelMouseClicked
        if (Integer.valueOf(_orangeNumberLabel.getText()) != 0) {
            _orangeNumberLabel.setText(String.valueOf(Integer.valueOf(_orangeNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
            if (_isOrange) {
                _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) - 1));
            }
        }
    }//GEN-LAST:event__orangeMinusLabelMouseClicked

    private void _orangeNumberLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__orangeNumberLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event__orangeNumberLabelMouseClicked

    private void _orangeAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__orangeAddLabelMouseClicked
        _orangeNumberLabel.setText(String.valueOf(Integer.valueOf(_orangeNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        if (_isOrange) {
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) + 1));
        }
    }//GEN-LAST:event__orangeAddLabelMouseClicked

    private void _lemonMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lemonMinusLabelMouseClicked
        if (Integer.valueOf(_lemonNumberLabel.getText()) != 0) {
            _lemonNumberLabel.setText(String.valueOf(Integer.valueOf(_lemonNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
            if (_isLemon) {
                _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) - 1));
            }
        }
    }//GEN-LAST:event__lemonMinusLabelMouseClicked

    private void _lemonNumberLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lemonNumberLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event__lemonNumberLabelMouseClicked

    private void _lemonAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__lemonAddLabelMouseClicked
        _lemonNumberLabel.setText(String.valueOf(Integer.valueOf(_lemonNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        if (_isLemon) {
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) + 1));
        }
    }//GEN-LAST:event__lemonAddLabelMouseClicked

    private void _zeroMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__zeroMinusLabelMouseClicked
        if (Integer.valueOf(_zeroNumberLabel.getText()) != 0) {
            _zeroNumberLabel.setText(String.valueOf(Integer.valueOf(_zeroNumberLabel.getText()) -1));
            _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
            if (_isZero) {
                _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) - 1));
            }
        }
    }//GEN-LAST:event__zeroMinusLabelMouseClicked

    private void _zeroNumberLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__zeroNumberLabelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event__zeroNumberLabelMouseClicked

    private void _zeroAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__zeroAddLabelMouseClicked
        _zeroNumberLabel.setText(String.valueOf(Integer.valueOf(_zeroNumberLabel.getText()) +1));
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        if (_isZero) {
            _sodaNumberLabel.setText(String.valueOf(Integer.valueOf(_sodaNumberLabel.getText()) + 1));
        }
    }//GEN-LAST:event__zeroAddLabelMouseClicked

    private void _sodaTrashLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__sodaTrashLabelMouseClicked
        _isSquirted = false;
        _sodaAddLabel.setVisible(false);
        _sodaMinusLabel.setVisible(false);
        _sodaNumberLabel.setVisible(false);
        _sodaTrashLabel.setVisible(false);
        _sodaCardboardLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/ice.png")));
        _sodaCardboardLabelMouseReleased(evt);
    }//GEN-LAST:event__sodaTrashLabelMouseClicked

    private void _pizzasLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzasLabelMouseClicked

        _backLabel.setVisible(true);
        _cardsPanel.removeAll();
        _cardsPanel.add(_pizzasCard);
        _cardsPanel.repaint();
        _cardsPanel.revalidate();
    }//GEN-LAST:event__pizzasLabelMouseClicked

    private void _tomatoLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tomatoLabelMouseClicked
        if (_currentPizza != -1) {
            _tickCreamLabel.setVisible(false);
            _tickTomatoLabel.setVisible(!_tickTomatoLabel.isVisible());
            _tickBarbacueLabel.setVisible(false);
            _tickBourbonLabel.setVisible(false);
            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza = "/img/pizza.png";
            _pizzas.get(_currentPizza).setSauce(0);
            if (_tickTomatoLabel.isVisible()) {
                pizza = "/img/pizzared.png";
                _pizzas.get(_currentPizza).setSauce(2);
            }
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        }
    }//GEN-LAST:event__tomatoLabelMouseClicked

    private void _mediumLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__mediumLabelMouseClicked
        if (_currentPizza != -1) {
            _tickMediumLabel.setVisible(true);
            _tickFamiliarLabel.setVisible(false);
            _pizzas.get(_currentPizza).setSize(0);
            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza;
            if (_pizzas.get(_currentPizza).getSauce() == 0) {
                pizza = "/img/pizza.png";
            } else if (_pizzas.get(_currentPizza).getSauce() == 1) {
                pizza = "/img/pizzawhite.png";
            } else {
                pizza = "/img/pizzared.png";
            }
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        }
    }//GEN-LAST:event__mediumLabelMouseClicked

    private void _saveLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__saveLabelMouseClicked
        if(_currentPizza != -1) {
            _pizzas.get(_currentPizza).setName(_pizzaField.getText());
        }
        _nPizzas++;
        _currentPizza = _nPizzas-1;
        Pizza pizza = new Pizza();
        _pizzas.add(pizza);
        _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pizza.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
        _pizzaLabel.setVisible(true);
        if (_currentPizza > 0) {
            _previousLabel.setVisible(true);
        }
        _nextLabel.setVisible(false);
        _pizzaField.setText("Personalizada " + String.valueOf(_custom +1));
        _custom++;
        _pizzas.get(_currentPizza).setName(_pizzaField.getText());
        _pizzaField.setVisible(true);
        _deleteLabel.setVisible(true);
        _deleteTittleLabel.setVisible(true);
        _pizzaNumberLabel.setText("1");
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        _pizzaAddLabel.setVisible(true);
        _pizzaMinusLabel.setVisible(true);
        _pizzaNumberLabel.setVisible(true);
        
        _cornsLabel.setVisible(false);
        _olivesLabel.setVisible(false);
        _pineapplesLabel.setVisible(false);
        _caramelsLabel.setVisible(false);
        _onionsLabel.setVisible(false);
        _peppersLabel.setVisible(false);
        _mushroomsLabel.setVisible(false);
        _tunasLabel.setVisible(false);
        _anchoviesLabel.setVisible(false);
        _beefsLabel.setVisible(false);
        _chickensLabel.setVisible(false);
        _yorksLabel.setVisible(false);
        _hamsLabel.setVisible(false);
        _baconsLabel.setVisible(false);
        _pepperonisLabel.setVisible(false);
        _tomatoesLabel.setVisible(false);
        
        _tickTomatoLabel.setVisible(false);
        _tickBarbacueLabel.setVisible(false);
        _tickCreamLabel.setVisible(false);
        _tickBourbonLabel.setVisible(false);
        _tickOliveLabel.setVisible(false);
        _tickAnchovyLabel.setVisible(false);
        _tickTunaLabel.setVisible(false);
        _tickBaconLabel.setVisible(false);
        _tickOnionLabel.setVisible(false);
        _tickMushroomLabel.setVisible(false);
        _tickYorkLabel.setVisible(false);
        _tickHamLabel.setVisible(false);
        _tickCornLabel.setVisible(false);
        _tickPepperoniLabel.setVisible(false);
        _tickPepperLabel.setVisible(false);
        _tickPineappleLabel.setVisible(false);
        _tickChickenLabel.setVisible(false);
        _tickBeefLabel.setVisible(false);
        _tickTomatoeLabel.setVisible(false);
        _tickCaramelLabel.setVisible(false);
        _tickFinizzimaLabel.setVisible(false);
        _tickOriginalLabel.setVisible(true);
        _tickPanLabel.setVisible(false);
        _tickMediumLabel.setVisible(true);
        _tickFamiliarLabel.setVisible(false);
    }//GEN-LAST:event__saveLabelMouseClicked

    private void _previousLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__previousLabelMouseClicked
        _pizzas.get(_currentPizza).setName(_pizzaField.getText());
        _currentPizza--;
        if (_currentPizza == 0) {
            _previousLabel.setVisible(false);
        }
        _nextLabel.setVisible(true);
        
        _pizzaField.setText(_pizzas.get(_currentPizza).getName());
        _pizzaNumberLabel.setText(String.valueOf(_pizzas.get(_currentPizza).getNumber()));
        
        int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
        String pizza;
        if (_pizzas.get(_currentPizza).getSauce() == 0) {
            pizza = "/img/pizza.png";
        } else if (_pizzas.get(_currentPizza).getSauce() == 1) {
            pizza = "/img/pizzawhite.png";
        } else {
            pizza = "/img/pizzared.png";
        }
        
        _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        
        _tickTomatoLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 2);
        _tickBarbacueLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 3);
        _tickCreamLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 1);
        _tickBourbonLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 4);
        _tickOliveLabel.setVisible(_pizzas.get(_currentPizza).isOlives());
        _tickAnchovyLabel.setVisible(_pizzas.get(_currentPizza).isAnchovies());
        _tickTunaLabel.setVisible(_pizzas.get(_currentPizza).isTuna());
        _tickBaconLabel.setVisible(_pizzas.get(_currentPizza).isBacon());
        _tickOnionLabel.setVisible(_pizzas.get(_currentPizza).isOnion());
        _tickMushroomLabel.setVisible(_pizzas.get(_currentPizza).isMushrooms());
        _tickYorkLabel.setVisible(_pizzas.get(_currentPizza).isYork());
        _tickHamLabel.setVisible(_pizzas.get(_currentPizza).isHam());
        _tickCornLabel.setVisible(_pizzas.get(_currentPizza).isCorn());
        _tickPepperoniLabel.setVisible(_pizzas.get(_currentPizza).isPepperoni());
        _tickPepperLabel.setVisible(_pizzas.get(_currentPizza).isPepper());
        _tickPineappleLabel.setVisible(_pizzas.get(_currentPizza).isPineapple());
        _tickChickenLabel.setVisible(_pizzas.get(_currentPizza).isChicken());
        _tickBeefLabel.setVisible(_pizzas.get(_currentPizza).isBeef());
        _tickTomatoeLabel.setVisible(_pizzas.get(_currentPizza).isTomato());
        _tickCaramelLabel.setVisible(_pizzas.get(_currentPizza).isCaramel());
        _tickFinizzimaLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 0);
        _tickOriginalLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 1);
        _tickPanLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 2);
        _tickMediumLabel.setVisible(_pizzas.get(_currentPizza).getSize() == 0);
        _tickFamiliarLabel.setVisible(_pizzas.get(_currentPizza).getSize() == 1);
        
        _cornsLabel.setVisible(_tickCornLabel.isVisible());
        _olivesLabel.setVisible(_tickOliveLabel.isVisible());
        _pineapplesLabel.setVisible(_tickPineappleLabel.isVisible());
        _caramelsLabel.setVisible(_tickCaramelLabel.isVisible());
        _onionsLabel.setVisible(_tickOnionLabel.isVisible());
        _peppersLabel.setVisible(_tickPepperLabel.isVisible());
        _mushroomsLabel.setVisible(_tickMushroomLabel.isVisible());
        _tunasLabel.setVisible(_tickTunaLabel.isVisible());
        _anchoviesLabel.setVisible(_tickAnchovyLabel.isVisible());
        _beefsLabel.setVisible(_tickBeefLabel.isVisible());
        _chickensLabel.setVisible(_tickChickenLabel.isVisible());
        _yorksLabel.setVisible(_tickYorkLabel.isVisible());
        _hamsLabel.setVisible(_tickHamLabel.isVisible());
        _baconsLabel.setVisible(_tickBaconLabel.isVisible());
        _pepperonisLabel.setVisible(_tickPepperoniLabel.isVisible());
        _tomatoesLabel.setVisible(_tickTomatoeLabel.isVisible());
    }//GEN-LAST:event__previousLabelMouseClicked

    private void _nextLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__nextLabelMouseClicked
        _pizzas.get(_currentPizza).setName(_pizzaField.getText());
        _currentPizza++;
        if (_currentPizza == _nPizzas -1) {
            _nextLabel.setVisible(false);
        }
        _previousLabel.setVisible(true);
        
        _pizzaField.setText(_pizzas.get(_currentPizza).getName());
        _pizzaNumberLabel.setText(String.valueOf(_pizzas.get(_currentPizza).getNumber()));
        
        int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
        String pizza;
        if (_pizzas.get(_currentPizza).getSauce() == 0) {
            pizza = "/img/pizza.png";
        } else if (_pizzas.get(_currentPizza).getSauce() == 1) {
            pizza = "/img/pizzawhite.png";
        } else {
            pizza = "/img/pizzared.png";
        }
        
        _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        
        _tickTomatoLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 2);
        _tickBarbacueLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 3);
        _tickCreamLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 1);
        _tickBourbonLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 4);
        _tickOliveLabel.setVisible(_pizzas.get(_currentPizza).isOlives());
        _tickAnchovyLabel.setVisible(_pizzas.get(_currentPizza).isAnchovies());
        _tickTunaLabel.setVisible(_pizzas.get(_currentPizza).isTuna());
        _tickBaconLabel.setVisible(_pizzas.get(_currentPizza).isBacon());
        _tickOnionLabel.setVisible(_pizzas.get(_currentPizza).isOnion());
        _tickMushroomLabel.setVisible(_pizzas.get(_currentPizza).isMushrooms());
        _tickYorkLabel.setVisible(_pizzas.get(_currentPizza).isYork());
        _tickHamLabel.setVisible(_pizzas.get(_currentPizza).isHam());
        _tickCornLabel.setVisible(_pizzas.get(_currentPizza).isCorn());
        _tickPepperoniLabel.setVisible(_pizzas.get(_currentPizza).isPepperoni());
        _tickPepperLabel.setVisible(_pizzas.get(_currentPizza).isPepper());
        _tickPineappleLabel.setVisible(_pizzas.get(_currentPizza).isPineapple());
        _tickChickenLabel.setVisible(_pizzas.get(_currentPizza).isChicken());
        _tickBeefLabel.setVisible(_pizzas.get(_currentPizza).isBeef());
        _tickTomatoeLabel.setVisible(_pizzas.get(_currentPizza).isTomato());
        _tickCaramelLabel.setVisible(_pizzas.get(_currentPizza).isCaramel());
        _tickFinizzimaLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 0);
        _tickOriginalLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 1);
        _tickPanLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 2);
        _tickMediumLabel.setVisible(_pizzas.get(_currentPizza).getSize() == 0);
        _tickFamiliarLabel.setVisible(_pizzas.get(_currentPizza).getSize() == 1);
        
        _cornsLabel.setVisible(_tickCornLabel.isVisible());
        _olivesLabel.setVisible(_tickOliveLabel.isVisible());
        _pineapplesLabel.setVisible(_tickPineappleLabel.isVisible());
        _caramelsLabel.setVisible(_tickCaramelLabel.isVisible());
        _onionsLabel.setVisible(_tickOnionLabel.isVisible());
        _peppersLabel.setVisible(_tickPepperLabel.isVisible());
        _mushroomsLabel.setVisible(_tickMushroomLabel.isVisible());
        _tunasLabel.setVisible(_tickTunaLabel.isVisible());
        _anchoviesLabel.setVisible(_tickAnchovyLabel.isVisible());
        _beefsLabel.setVisible(_tickBeefLabel.isVisible());
        _chickensLabel.setVisible(_tickChickenLabel.isVisible());
        _yorksLabel.setVisible(_tickYorkLabel.isVisible());
        _hamsLabel.setVisible(_tickHamLabel.isVisible());
        _baconsLabel.setVisible(_tickBaconLabel.isVisible());
        _pepperonisLabel.setVisible(_tickPepperoniLabel.isVisible());
        _tomatoesLabel.setVisible(_tickTomatoeLabel.isVisible());
    }//GEN-LAST:event__nextLabelMouseClicked

    private void _pizzaMinusLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaMinusLabelMouseClicked
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) -1));
        _pizzaNumberLabel.setText(String.valueOf(Integer.valueOf(_pizzaNumberLabel.getText()) -1));
        _pizzas.get(_currentPizza).setNumber(Integer.valueOf(_pizzaNumberLabel.getText()));
        if ("0".equals(_pizzaNumberLabel.getText())) {
            _deleteLabelMouseClicked(evt);
        }
    }//GEN-LAST:event__pizzaMinusLabelMouseClicked

    private void _pizzaAddLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaAddLabelMouseClicked
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) +1));
        _pizzaNumberLabel.setText(String.valueOf(Integer.valueOf(_pizzaNumberLabel.getText()) +1));
        _pizzas.get(_currentPizza).setNumber(Integer.valueOf(_pizzaNumberLabel.getText()));
    }//GEN-LAST:event__pizzaAddLabelMouseClicked

    private void _deleteLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__deleteLabelMouseClicked
        _orderItemsLabel.setText(String.valueOf(Integer.valueOf(_orderItemsLabel.getText()) - Integer.valueOf(_pizzaNumberLabel.getText())));
        _pizzas.remove(_currentPizza);
        _nPizzas--;
        if (_nPizzas == 0) {
            _pizzaField.setVisible(false);
            _pizzaAddLabel.setVisible(false);
            _pizzaMinusLabel.setVisible(false);
            _pizzaNumberLabel.setVisible(false);
            _dishLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/dish.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pizza.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));
            _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(335, 335, Image.SCALE_SMOOTH)));

            _pizzaLabel.setVisible(false);
            _deleteLabel.setVisible(false);
            _deleteTittleLabel.setVisible(false);

            _tickTomatoLabel.setVisible(false);
            _tickBarbacueLabel.setVisible(false);
            _tickCreamLabel.setVisible(false);
            _tickBourbonLabel.setVisible(false);
            _tickOliveLabel.setVisible(false);
            _tickAnchovyLabel.setVisible(false);
            _tickTunaLabel.setVisible(false);
            _tickBaconLabel.setVisible(false);
            _tickOnionLabel.setVisible(false);
            _tickMushroomLabel.setVisible(false);
            _tickYorkLabel.setVisible(false);
            _tickHamLabel.setVisible(false);
            _tickCornLabel.setVisible(false);
            _tickPepperoniLabel.setVisible(false);
            _tickPepperLabel.setVisible(false);
            _tickPineappleLabel.setVisible(false);
            _tickChickenLabel.setVisible(false);
            _tickBeefLabel.setVisible(false);
            _tickTomatoeLabel.setVisible(false);
            _tickCaramelLabel.setVisible(false);
            _tickFinizzimaLabel.setVisible(false);
            _tickOriginalLabel.setVisible(false);
            _tickPanLabel.setVisible(false);
            _tickMediumLabel.setVisible(false);
            _tickFamiliarLabel.setVisible(false);

            _previousLabel.setVisible(false);
            _nextLabel.setVisible(false);


            _cornsLabel.setVisible(false);
            _olivesLabel.setVisible(false);
            _pineapplesLabel.setVisible(false);
            _caramelsLabel.setVisible(false);
            _onionsLabel.setVisible(false);
            _peppersLabel.setVisible(false);
            _mushroomsLabel.setVisible(false);
            _tunasLabel.setVisible(false);
            _anchoviesLabel.setVisible(false);
            _beefsLabel.setVisible(false);
            _chickensLabel.setVisible(false);
            _yorksLabel.setVisible(false);
            _hamsLabel.setVisible(false);
            _baconsLabel.setVisible(false);
            _pepperonisLabel.setVisible(false);
            _tomatoesLabel.setVisible(false);
            
            _currentPizza--;
        }
        else {
            if(_currentPizza == _nPizzas) {
                _currentPizza--;
                _previousLabel.setVisible(true);
                _nextLabel.setVisible(false);
            }
            if (_currentPizza == 0) {
                _previousLabel.setVisible(false);
            } else {
                _previousLabel.setVisible(true);
            }
            if (_currentPizza == _nPizzas -1) {
                _nextLabel.setVisible(false);
            } else {
                _nextLabel.setVisible(true);
            }

            _pizzaField.setText(_pizzas.get(_currentPizza).getName());
            _pizzaNumberLabel.setText(String.valueOf(_pizzas.get(_currentPizza).getNumber()));

            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza;
            if (_pizzas.get(_currentPizza).getSauce() == 0) {
                pizza = "/img/pizza.png";
            } else if (_pizzas.get(_currentPizza).getSauce() == 1) {
                pizza = "/img/pizzawhite.png";
            } else {
                pizza = "/img/pizzared.png";
            }

            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));

            _tickTomatoLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 2);
            _tickBarbacueLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 3);
            _tickCreamLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 1);
            _tickBourbonLabel.setVisible(_pizzas.get(_currentPizza).getSauce() == 4);
            _tickOliveLabel.setVisible(_pizzas.get(_currentPizza).isOlives());
            _tickAnchovyLabel.setVisible(_pizzas.get(_currentPizza).isAnchovies());
            _tickTunaLabel.setVisible(_pizzas.get(_currentPizza).isTuna());
            _tickBaconLabel.setVisible(_pizzas.get(_currentPizza).isBacon());
            _tickOnionLabel.setVisible(_pizzas.get(_currentPizza).isOnion());
            _tickMushroomLabel.setVisible(_pizzas.get(_currentPizza).isMushrooms());
            _tickYorkLabel.setVisible(_pizzas.get(_currentPizza).isYork());
            _tickHamLabel.setVisible(_pizzas.get(_currentPizza).isHam());
            _tickCornLabel.setVisible(_pizzas.get(_currentPizza).isCorn());
            _tickPepperoniLabel.setVisible(_pizzas.get(_currentPizza).isPepperoni());
            _tickPepperLabel.setVisible(_pizzas.get(_currentPizza).isPepper());
            _tickPineappleLabel.setVisible(_pizzas.get(_currentPizza).isPineapple());
            _tickChickenLabel.setVisible(_pizzas.get(_currentPizza).isChicken());
            _tickBeefLabel.setVisible(_pizzas.get(_currentPizza).isBeef());
            _tickTomatoeLabel.setVisible(_pizzas.get(_currentPizza).isTomato());
            _tickCaramelLabel.setVisible(_pizzas.get(_currentPizza).isCaramel());
            _tickFinizzimaLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 0);
            _tickOriginalLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 1);
            _tickPanLabel.setVisible(_pizzas.get(_currentPizza).getDough() == 2);
            _tickMediumLabel.setVisible(_pizzas.get(_currentPizza).getSize() == 0);
            _tickFamiliarLabel.setVisible(_pizzas.get(_currentPizza).getSize() == 1);

            _cornsLabel.setVisible(_tickCornLabel.isVisible());
            _olivesLabel.setVisible(_tickOliveLabel.isVisible());
            _pineapplesLabel.setVisible(_tickPineappleLabel.isVisible());
            _caramelsLabel.setVisible(_tickCaramelLabel.isVisible());
            _onionsLabel.setVisible(_tickOnionLabel.isVisible());
            _peppersLabel.setVisible(_tickPepperLabel.isVisible());
            _mushroomsLabel.setVisible(_tickMushroomLabel.isVisible());
            _tunasLabel.setVisible(_tickTunaLabel.isVisible());
            _anchoviesLabel.setVisible(_tickAnchovyLabel.isVisible());
            _beefsLabel.setVisible(_tickBeefLabel.isVisible());
            _chickensLabel.setVisible(_tickChickenLabel.isVisible());
            _yorksLabel.setVisible(_tickYorkLabel.isVisible());
            _hamsLabel.setVisible(_tickHamLabel.isVisible());
            _baconsLabel.setVisible(_tickBaconLabel.isVisible());
            _pepperonisLabel.setVisible(_tickPepperoniLabel.isVisible());
            _tomatoesLabel.setVisible(_tickTomatoeLabel.isVisible());
        }
        
    }//GEN-LAST:event__deleteLabelMouseClicked

    private void _creamLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__creamLabelMouseClicked
        if (_currentPizza != -1) {
            _tickCreamLabel.setVisible(!_tickCreamLabel.isVisible());
            _tickTomatoLabel.setVisible(false);
            _tickBarbacueLabel.setVisible(false);
            _tickBourbonLabel.setVisible(false);
            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza = "/img/pizza.png";
            _pizzas.get(_currentPizza).setSauce(0);
            if (_tickCreamLabel.isVisible()) {
                pizza = "/img/pizzawhite.png";
                _pizzas.get(_currentPizza).setSauce(1);
            }
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        }
    }//GEN-LAST:event__creamLabelMouseClicked

    private void _barbacueLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__barbacueLabelMouseClicked
        if (_currentPizza != -1) {
            _tickCreamLabel.setVisible(false);
            _tickTomatoLabel.setVisible(false);
            _tickBarbacueLabel.setVisible(!_tickBarbacueLabel.isVisible());
            _tickBourbonLabel.setVisible(false);
            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza = "/img/pizza.png";
            _pizzas.get(_currentPizza).setSauce(0);
            if (_tickBarbacueLabel.isVisible()) {
                pizza = "/img/pizzared.png";
                _pizzas.get(_currentPizza).setSauce(3);
            }
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        }
    }//GEN-LAST:event__barbacueLabelMouseClicked

    private void _bourbonLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__bourbonLabelMouseClicked
        if (_currentPizza != -1) {
            _tickCreamLabel.setVisible(false);
            _tickTomatoLabel.setVisible(false);
            _tickBarbacueLabel.setVisible(false);
            _tickBourbonLabel.setVisible(!_tickBourbonLabel.isVisible());
            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza = "/img/pizza.png";
            _pizzas.get(_currentPizza).setSauce(0);
            if (_tickBourbonLabel.isVisible()) {
                pizza = "/img/pizzared.png";
                _pizzas.get(_currentPizza).setSauce(4);
            }
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        }
    }//GEN-LAST:event__bourbonLabelMouseClicked

    private void _familiarLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__familiarLabelMouseClicked
        if (_currentPizza != -1) {
            _tickMediumLabel.setVisible(false);
            _tickFamiliarLabel.setVisible(true);
            _pizzas.get(_currentPizza).setSize(1);
            int size = 335 + 40 * _pizzas.get(_currentPizza).getSize();
            String pizza;
            if (_pizzas.get(_currentPizza).getSauce() == 0) {
                pizza = "/img/pizza.png";
            } else if (_pizzas.get(_currentPizza).getSauce() == 1) {
                pizza = "/img/pizzawhite.png";
            } else {
                pizza = "/img/pizzared.png";
            }
            _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
            _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(size, size, Image.SCALE_SMOOTH)));
        }
    }//GEN-LAST:event__familiarLabelMouseClicked

    private void _finizzimaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__finizzimaLabelMouseClicked
        if (_currentPizza != -1) {
            _tickFinizzimaLabel.setVisible(true);
            _tickOriginalLabel.setVisible(false);
            _tickPanLabel.setVisible(false);
            _pizzas.get(_currentPizza).setDough(0);
        }
    }//GEN-LAST:event__finizzimaLabelMouseClicked

    private void _originalLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__originalLabelMouseClicked
        if (_currentPizza != -1) {
            _tickFinizzimaLabel.setVisible(false);
            _tickOriginalLabel.setVisible(true);
            _tickPanLabel.setVisible(false);
            _pizzas.get(_currentPizza).setDough(1);
        }
    }//GEN-LAST:event__originalLabelMouseClicked

    private void _panLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__panLabelMouseClicked
        if (_currentPizza != -1) {
            _tickFinizzimaLabel.setVisible(false);
            _tickOriginalLabel.setVisible(false);
            _tickPanLabel.setVisible(true);
            _pizzas.get(_currentPizza).setDough(2);
        }
    }//GEN-LAST:event__panLabelMouseClicked

    private void _oliveLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__oliveLabelMouseClicked
        if (_currentPizza != -1) {
            _olivesLabel.setVisible(!_olivesLabel.isVisible());
            _tickOliveLabel.setVisible(_olivesLabel.isVisible());
            _pizzas.get(_currentPizza).setOlives(_olivesLabel.isVisible());
        }
    }//GEN-LAST:event__oliveLabelMouseClicked

    private void _anchovyLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__anchovyLabelMouseClicked
        if (_currentPizza != -1) {
            _anchoviesLabel.setVisible(!_anchoviesLabel.isVisible());
            _tickAnchovyLabel.setVisible(_anchoviesLabel.isVisible());
            _pizzas.get(_currentPizza).setAnchovies(_anchoviesLabel.isVisible());
        }
    }//GEN-LAST:event__anchovyLabelMouseClicked

    private void _tunaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tunaLabelMouseClicked
        if (_currentPizza != -1) {
            _tunasLabel.setVisible(!_tunasLabel.isVisible());
            _tickTunaLabel.setVisible(_tunasLabel.isVisible());
            _pizzas.get(_currentPizza).setTuna(_tunasLabel.isVisible());
        }
    }//GEN-LAST:event__tunaLabelMouseClicked

    private void _baconLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__baconLabelMouseClicked
        if (_currentPizza != -1) {
            _baconsLabel.setVisible(!_baconsLabel.isVisible());
            _tickBaconLabel.setVisible(_baconsLabel.isVisible());
            _pizzas.get(_currentPizza).setBacon(_baconsLabel.isVisible());
        }
    }//GEN-LAST:event__baconLabelMouseClicked

    private void _onionLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__onionLabelMouseClicked
        if (_currentPizza != -1) {
            _onionsLabel.setVisible(!_onionsLabel.isVisible());
            _tickOnionLabel.setVisible(_onionsLabel.isVisible());
            _pizzas.get(_currentPizza).setOnion(_olivesLabel.isVisible());
        }
    }//GEN-LAST:event__onionLabelMouseClicked

    private void _mushroomLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__mushroomLabelMouseClicked
        if (_currentPizza != -1) {
            _mushroomsLabel.setVisible(!_mushroomsLabel.isVisible());
            _tickMushroomLabel.setVisible(_mushroomsLabel.isVisible());
            _pizzas.get(_currentPizza).setMushrooms(_mushroomsLabel.isVisible());
        }
    }//GEN-LAST:event__mushroomLabelMouseClicked

    private void _yorkLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__yorkLabelMouseClicked
        if (_currentPizza != -1) {
            _yorksLabel.setVisible(!_yorksLabel.isVisible());
            _tickYorkLabel.setVisible(_yorksLabel.isVisible());
            _pizzas.get(_currentPizza).setYork(_olivesLabel.isVisible());
        }
    }//GEN-LAST:event__yorkLabelMouseClicked

    private void _hamLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__hamLabelMouseClicked
        if (_currentPizza != -1) {
            _hamsLabel.setVisible(!_hamsLabel.isVisible());
            _tickHamLabel.setVisible(_hamsLabel.isVisible());
            _pizzas.get(_currentPizza).setHam(_hamsLabel.isVisible());
        }
    }//GEN-LAST:event__hamLabelMouseClicked

    private void _cornLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cornLabelMouseClicked
        if (_currentPizza != -1) {
            _cornsLabel.setVisible(!_cornsLabel.isVisible());
            _tickCornLabel.setVisible(_cornsLabel.isVisible());
            _pizzas.get(_currentPizza).setCorn(_cornsLabel.isVisible());
        }
    }//GEN-LAST:event__cornLabelMouseClicked

    private void _pepperoniLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepperoniLabelMouseClicked
        if (_currentPizza != -1) {
            _pepperonisLabel.setVisible(!_pepperonisLabel.isVisible());
            _tickPepperoniLabel.setVisible(_pepperonisLabel.isVisible());
            _pizzas.get(_currentPizza).setPepperoni(_pepperonisLabel.isVisible());
        }
    }//GEN-LAST:event__pepperoniLabelMouseClicked

    private void _pepperLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepperLabelMouseClicked
        if (_currentPizza != -1) {
            _peppersLabel.setVisible(!_peppersLabel.isVisible());
            _tickPepperLabel.setVisible(_peppersLabel.isVisible());
            _pizzas.get(_currentPizza).setPepper(_peppersLabel.isVisible());
        }
    }//GEN-LAST:event__pepperLabelMouseClicked

    private void _pineappleLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pineappleLabelMouseClicked
        if (_currentPizza != -1) {
            _pineapplesLabel.setVisible(!_pineapplesLabel.isVisible());
            _tickPineappleLabel.setVisible(_pineapplesLabel.isVisible());
            _pizzas.get(_currentPizza).setPineapple(_pineapplesLabel.isVisible());
        }
    }//GEN-LAST:event__pineappleLabelMouseClicked

    private void _pizzaChickenLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaChickenLabelMouseClicked
        if (_currentPizza != -1) {
            _chickensLabel.setVisible(!_chickensLabel.isVisible());
            _tickChickenLabel.setVisible(_chickensLabel.isVisible());
            _pizzas.get(_currentPizza).setChicken(_chickensLabel.isVisible());
        }
    }//GEN-LAST:event__pizzaChickenLabelMouseClicked

    private void _beefLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__beefLabelMouseClicked
        if (_currentPizza != -1) {
            _beefsLabel.setVisible(!_beefsLabel.isVisible());
            _tickBeefLabel.setVisible(_beefsLabel.isVisible());
            _pizzas.get(_currentPizza).setBeef(_beefsLabel.isVisible());
        }
    }//GEN-LAST:event__beefLabelMouseClicked

    private void _tomateLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tomateLabelMouseClicked
        if (_currentPizza != -1) {
            _tomatoesLabel.setVisible(!_tomatoesLabel.isVisible());
            _tickTomatoeLabel.setVisible(_tomatoesLabel.isVisible());
            _pizzas.get(_currentPizza).setTomato(_tomatoesLabel.isVisible());
        }
    }//GEN-LAST:event__tomateLabelMouseClicked

    private void _caramelPizzaLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelPizzaLabelMouseClicked
        if (_currentPizza != -1) {
            _caramelsLabel.setVisible(!_caramelsLabel.isVisible());
            _tickCaramelLabel.setVisible(_caramelsLabel.isVisible());
            _pizzas.get(_currentPizza).setCaramel(_caramelsLabel.isVisible());
        }
    }//GEN-LAST:event__caramelPizzaLabelMouseClicked

    private void _backLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__backLabelMouseClicked
            _backLabel.setVisible(false);
            _cardsPanel.removeAll();
            _cardsPanel.add(_menuCard);
            _cardsPanel.repaint();
            _cardsPanel.revalidate();
    }//GEN-LAST:event__backLabelMouseClicked

    private void _pizzaDragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaDragMouseDragged
        if(_currentPizza != -1) {
            double distance = Math.sqrt(Math.pow(150 - evt.getX(), 2) + Math.pow(150 - evt.getY(), 2));
            if ((int)(distance+45)*2 >= 335 && (int)(distance+45)*2 <= 375) {
                String pizza = "/img/pizza.png";
                if (_pizzas.get(_currentPizza).getSauce() == 1) {
                    pizza = "/img/pizzawhite.png";
                } else if (_pizzas.get(_currentPizza).getSauce() > 1) {
                    pizza = "/img/pizzared.png";
                }
                
                _distance = (int)(distance+45)*2;
                
                _pizzaLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource(pizza)).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _cornsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/corns.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _olivesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/olives_1.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _pineapplesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pineapples.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _caramelsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/caramels.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _onionsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/onions.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _peppersLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/peppers.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _mushroomsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/mushrooms.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _tunasLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tunas.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _anchoviesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/anchovies.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _beefsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/beefs.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _chickensLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/chickens.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _yorksLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/yorks.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _hamsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/hams.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _baconsLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/bacons.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _pepperonisLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/pepperonis.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                _tomatoesLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/tomatoes.png")).getImage().getScaledInstance(_distance, _distance, Image.SCALE_SMOOTH)));
                
                if (_distance < 355) {
                    _tickMediumLabel.setVisible(true);
                    _tickFamiliarLabel.setVisible(false);
                } else {
                    _tickMediumLabel.setVisible(false);
                    _tickFamiliarLabel.setVisible(true);
                }
            }
        }
    }//GEN-LAST:event__pizzaDragMouseDragged

    private void _pizzaDragMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaDragMouseReleased
        if(_currentPizza != -1) {
            if (_distance < 355) {
                _mediumLabelMouseClicked(evt);
            } else {
                _familiarLabelMouseClicked(evt);
            }
        }
    }//GEN-LAST:event__pizzaDragMouseReleased

    private void _oliveLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__oliveLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_oliveLabel.getIcon());
            _draggableLabel.setLocation(_oliveLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__oliveLabelMouseDragged

    private void _anchovyLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__anchovyLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_anchovyLabel.getIcon());
            _draggableLabel.setLocation(_anchovyLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__anchovyLabelMouseDragged

    private void _tunaLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tunaLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_tunaLabel.getIcon());
            _draggableLabel.setLocation(_tunaLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__tunaLabelMouseDragged

    private void _baconLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__baconLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_baconLabel.getIcon());
            _draggableLabel.setLocation(_baconLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__baconLabelMouseDragged

    private void _onionLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__onionLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_onionLabel.getIcon());
            _draggableLabel.setLocation(_onionLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__onionLabelMouseDragged

    private void _mushroomLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__mushroomLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_mushroomLabel.getIcon());
            _draggableLabel.setLocation(_mushroomLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__mushroomLabelMouseDragged

    private void _yorkLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__yorkLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_yorkLabel.getIcon());
            _draggableLabel.setLocation(_yorkLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__yorkLabelMouseDragged

    private void _hamLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__hamLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_hamLabel.getIcon());
            _draggableLabel.setLocation(_hamLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__hamLabelMouseDragged

    private void _cornLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cornLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_cornLabel.getIcon());
            _draggableLabel.setLocation(_cornLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__cornLabelMouseDragged

    private void _pepperoniLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepperoniLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_pepperoniLabel.getIcon());
            _draggableLabel.setLocation(_pepperoniLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__pepperoniLabelMouseDragged

    private void _pepperLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepperLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_pepperLabel.getIcon());
            _draggableLabel.setLocation(_pepperLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__pepperLabelMouseDragged

    private void _pineappleLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pineappleLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_pineappleLabel.getIcon());
            _draggableLabel.setLocation(_pineappleLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__pineappleLabelMouseDragged

    private void _pizzaChickenLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaChickenLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_pizzaChickenLabel.getIcon());
            _draggableLabel.setLocation(_pizzaChickenLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__pizzaChickenLabelMouseDragged

    private void _beefLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__beefLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_beefLabel.getIcon());
            _draggableLabel.setLocation(_beefLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__beefLabelMouseDragged

    private void _tomateLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tomateLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_tomateLabel.getIcon());
            _draggableLabel.setLocation(_tomateLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__tomateLabelMouseDragged

    private void _caramelPizzaLabelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelPizzaLabelMouseDragged
        if (_currentPizza != -1) {
            _draggableLabel.setVisible(true);
            _draggableLabel.setIcon(_caramelPizzaLabel.getIcon());
            _draggableLabel.setLocation(_caramelPizzaLabel.getLocation());
            _draggableLabel.setLocation(_draggableLabel.getLocation().x + evt.getX() - _draggableLabel.getWidth()/2, _draggableLabel.getLocation().y + evt.getY() - _draggableLabel.getHeight()/2);
        }
        _isDragging = true;
    }//GEN-LAST:event__caramelPizzaLabelMouseDragged

    private void _oliveLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__oliveLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _olivesLabel.setVisible(true);
            _tickOliveLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setOlives(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__oliveLabelMouseReleased

    private void _anchovyLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__anchovyLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _anchoviesLabel.setVisible(true);
            _tickAnchovyLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setAnchovies(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__anchovyLabelMouseReleased

    private void _tunaLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tunaLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _tunasLabel.setVisible(true);
            _tickTunaLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setTuna(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__tunaLabelMouseReleased

    private void _baconLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__baconLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _baconsLabel.setVisible(true);
            _tickBaconLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setBacon(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__baconLabelMouseReleased

    private void _onionLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__onionLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _onionsLabel.setVisible(true);
            _tickOnionLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setOnion(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__onionLabelMouseReleased

    private void _mushroomLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__mushroomLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _mushroomsLabel.setVisible(true);
            _tickMushroomLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setMushrooms(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__mushroomLabelMouseReleased

    private void _yorkLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__yorkLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _yorksLabel.setVisible(true);
            _tickYorkLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setYork(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__yorkLabelMouseReleased

    private void _hamLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__hamLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _hamsLabel.setVisible(true);
            _tickHamLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setHam(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__hamLabelMouseReleased

    private void _cornLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__cornLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _cornsLabel.setVisible(true);
            _tickCornLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setCorn(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__cornLabelMouseReleased

    private void _pepperoniLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepperoniLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _pepperonisLabel.setVisible(true);
            _tickPepperoniLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setPepperoni(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__pepperoniLabelMouseReleased

    private void _pepperLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pepperLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _peppersLabel.setVisible(true);
            _tickPepperLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setPepper(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__pepperLabelMouseReleased

    private void _pineappleLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pineappleLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _pineapplesLabel.setVisible(true);
            _tickPineappleLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setPineapple(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__pineappleLabelMouseReleased

    private void _pizzaChickenLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__pizzaChickenLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _chickensLabel.setVisible(true);
            _tickChickenLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setChicken(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__pizzaChickenLabelMouseReleased

    private void _beefLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__beefLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _beefsLabel.setVisible(true);
            _tickBeefLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setBeef(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__beefLabelMouseReleased

    private void _tomateLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__tomateLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _tomatoesLabel.setVisible(true);
            _tickTomatoeLabel.setVisible(true);
            
            _pizzas.get(_currentPizza).setTomato(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__tomateLabelMouseReleased

    private void _caramelPizzaLabelMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__caramelPizzaLabelMouseReleased
        if (_currentPizza != -1 && _isDragging) {
            _caramelsLabel.setVisible(true);
            _tickCaramelLabel.setVisible(true);
            _draggableLabel.setVisible(false);
            _pizzas.get(_currentPizza).setCaramel(true);
        }
        _draggableLabel.setVisible(false);
        _isDragging = false;
    }//GEN-LAST:event__caramelPizzaLabelMouseReleased

    private void _itemsPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__itemsPanelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event__itemsPanelMouseClicked

    private void _itemsPanelMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__itemsPanelMouseDragged
        // TODO add your handling code here:
    }//GEN-LAST:event__itemsPanelMouseDragged

    private void _waiterPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event__waiterPanelMouseClicked
        _waiterLabel.setText("DE CAMINO");
        _waiterIconLabel.setIcon(new ImageIcon(new javax.swing.ImageIcon(getClass().getResource("/img/way.png")).getImage()));
    }//GEN-LAST:event__waiterPanelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DominosOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DominosOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DominosOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DominosOrder.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DominosOrder().setVisible(true);
            }
        });
    }

    
    List<Pizza> _pizzas = new ArrayList<Pizza>();
    private boolean _isDragging = false;
    private int _distance;
    private int _currentPizza = -1;
    private int _nPizzas = 0;
    private boolean _isSquirted = false;
    private boolean _isPepsi = false;
    private boolean _isLight = false;
    private boolean _isOrange = true;
    private boolean _isLemon = false;
    private boolean _isZero = false;
    private int _custom = 0;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel _anchoviesLabel;
    private javax.swing.JLabel _anchovyLabel;
    private javax.swing.JLabel _appleAddLabel;
    private javax.swing.JLabel _appleLabel;
    private javax.swing.JLabel _appleMinusLabel;
    private javax.swing.JLabel _appleNumberLabel;
    private javax.swing.JLabel _appleTittleLabel;
    private javax.swing.JLabel _backLabel;
    private javax.swing.JLabel _baconLabel;
    private javax.swing.JLabel _baconsLabel;
    private javax.swing.JLabel _barbacueLabel;
    private javax.swing.JLabel _barbacueTittleLabel;
    private javax.swing.JLabel _beefLabel;
    private javax.swing.JLabel _beefsLabel;
    private javax.swing.JPanel _beverageCard;
    private javax.swing.JLabel _beverageLabel;
    private javax.swing.JLabel _bourbonLabel;
    private javax.swing.JLabel _bourbonTittleLabel;
    private javax.swing.JLabel _breadAddLabel;
    private javax.swing.JLabel _breadLabel;
    private javax.swing.JLabel _breadMinusLabel;
    private javax.swing.JLabel _breadNumberLabel;
    private javax.swing.JLabel _breadTittleLabel;
    private javax.swing.JLabel _brownieAddLabel;
    private javax.swing.JLabel _brownieLabel;
    private javax.swing.JLabel _brownieMinusLabel;
    private javax.swing.JLabel _brownieNumberLabel;
    private javax.swing.JLabel _brownieTittleLabel;
    private javax.swing.JLabel _caramelAddLabel;
    private javax.swing.JLabel _caramelLabel;
    private javax.swing.JLabel _caramelMinusLabel;
    private javax.swing.JLabel _caramelNumberLabel;
    private javax.swing.JLabel _caramelPizzaLabel;
    private javax.swing.JLabel _caramelTittleLabel;
    private javax.swing.JLabel _caramelsLabel;
    private javax.swing.JPanel _cardsPanel;
    private javax.swing.JLabel _cheeseBreadAddLabel;
    private javax.swing.JLabel _cheeseBreadLabel;
    private javax.swing.JLabel _cheeseBreadMinusLabel;
    private javax.swing.JLabel _cheeseBreadNumberLabel;
    private javax.swing.JLabel _cheeseBreadTittleLabel;
    private javax.swing.JLabel _chickenAddLabel;
    private javax.swing.JLabel _chickenLabel;
    private javax.swing.JLabel _chickenMinusLabel;
    private javax.swing.JLabel _chickenNumberLabel;
    private javax.swing.JLabel _chickenTittleLabel;
    private javax.swing.JLabel _chickensLabel;
    private javax.swing.JLabel _chocolateAddLabel;
    private javax.swing.JLabel _chocolateLabel;
    private javax.swing.JLabel _chocolateMinusLabel;
    private javax.swing.JLabel _chocolateNumberLabel;
    private javax.swing.JLabel _chocolateTittleLabel;
    private javax.swing.JLabel _chunkyAddLabel;
    private javax.swing.JLabel _chunkyLabel;
    private javax.swing.JLabel _chunkyMinusLabel;
    private javax.swing.JLabel _chunkyNumberLabel;
    private javax.swing.JLabel _chunkyTittleLabel;
    private javax.swing.JLabel _confirmLabel;
    private javax.swing.JPanel _confirmPanel;
    private javax.swing.JPanel _containerPanel;
    private javax.swing.JLabel _cookiesAddLabel;
    private javax.swing.JLabel _cookiesLabel;
    private javax.swing.JLabel _cookiesMinusLabel;
    private javax.swing.JLabel _cookiesNumberLabel;
    private javax.swing.JLabel _cookiesTittleLabel;
    private javax.swing.JLabel _cornLabel;
    private javax.swing.JLabel _cornsLabel;
    private javax.swing.JLabel _creamLabel;
    private javax.swing.JLabel _creamTittleLabel;
    private javax.swing.JLabel _deleteLabel;
    private javax.swing.JLabel _deleteTittleLabel;
    private javax.swing.JPanel _dessertsCard;
    private javax.swing.JLabel _dessertsIconLabel;
    private javax.swing.JLabel _dessertsLabel;
    private javax.swing.JLabel _dishLabel;
    private javax.swing.JLabel _dominosLabel;
    private javax.swing.JLabel _doughAddLabel;
    private javax.swing.JLabel _doughLabel;
    private javax.swing.JLabel _doughMinusLabel;
    private javax.swing.JLabel _doughNumberLabel;
    private javax.swing.JLabel _doughTittleLabel;
    private javax.swing.JLabel _draggableLabel;
    private javax.swing.JPanel _drinksCard;
    private javax.swing.JPanel _drinksCardsPanel;
    private javax.swing.JLabel _drinksIconLabel;
    private javax.swing.JLabel _drinksLabel;
    private javax.swing.JLabel _familiarLabel;
    private javax.swing.JLabel _familiarTittleLabel;
    private javax.swing.JLabel _finizzimaLabel;
    private javax.swing.JLabel _finizzimaTittleLabel;
    private javax.swing.JLabel _hamLabel;
    private javax.swing.JLabel _hamsLabel;
    private javax.swing.JPanel _headCard;
    private javax.swing.JLabel _itemNameLabel;
    private javax.swing.JLabel _itemNumberLabel;
    private javax.swing.JLabel _itemPriceLabel;
    private javax.swing.JPanel _itemsPanel;
    private javax.swing.JLabel _kickersAddLabel;
    private javax.swing.JLabel _kickersLabel;
    private javax.swing.JLabel _kickersMinusLabel;
    private javax.swing.JLabel _kickersNumberLabel;
    private javax.swing.JLabel _kickersTittleLabel;
    private javax.swing.JLabel _lemonAddLabel;
    private javax.swing.JLabel _lemonLabel;
    private javax.swing.JLabel _lemonMinusLabel;
    private javax.swing.JLabel _lemonNumberLabel;
    private javax.swing.JLabel _lemonSquirtLabel;
    private javax.swing.JLabel _lightAddLabel;
    private javax.swing.JLabel _lightLabel;
    private javax.swing.JLabel _lightMinusLabel;
    private javax.swing.JLabel _lightNumberLabel;
    private javax.swing.JLabel _lightSquirtLabel;
    private javax.swing.JLabel _logoLabel;
    private javax.swing.JLabel _mediumLabel;
    private javax.swing.JLabel _mediumTittleLabel;
    private javax.swing.JPanel _menuCard;
    private javax.swing.JLabel _mushroomLabel;
    private javax.swing.JLabel _mushroomsLabel;
    private javax.swing.JPanel _navigatorPanel;
    private javax.swing.JLabel _nextLabel;
    private javax.swing.JLabel _oliveLabel;
    private javax.swing.JLabel _olivesLabel;
    private javax.swing.JLabel _onionLabel;
    private javax.swing.JLabel _onionsLabel;
    private javax.swing.JLabel _orangeAddLabel;
    private javax.swing.JLabel _orangeLabel;
    private javax.swing.JLabel _orangeMinusLabel;
    private javax.swing.JLabel _orangeNumberLabel;
    private javax.swing.JLabel _orangeSquirtLabel;
    private javax.swing.JLabel _orderIconLabel;
    private javax.swing.JLabel _orderItemsLabel;
    private javax.swing.JLabel _orderLabel;
    private javax.swing.JPanel _orderPanel;
    private javax.swing.JLabel _originalLabel;
    private javax.swing.JLabel _originalTittleLabel;
    private javax.swing.JLabel _panLabel;
    private javax.swing.JLabel _panTittleLabel;
    private javax.swing.JPanel _parentPanel;
    private javax.swing.JLabel _pepperLabel;
    private javax.swing.JLabel _pepperoniLabel;
    private javax.swing.JLabel _pepperonisLabel;
    private javax.swing.JLabel _peppersLabel;
    private javax.swing.JLabel _pepsiAddLabel;
    private javax.swing.JLabel _pepsiLabel;
    private javax.swing.JLabel _pepsiMinusLabel;
    private javax.swing.JLabel _pepsiNumberLabel;
    private javax.swing.JLabel _pepsiSquirtLabel;
    private javax.swing.JLabel _pineappleLabel;
    private javax.swing.JLabel _pineapplesLabel;
    private javax.swing.JLabel _pizzaAddLabel;
    private javax.swing.JLabel _pizzaChickenLabel;
    private javax.swing.JLabel _pizzaDrag;
    private javax.swing.JTextField _pizzaField;
    private javax.swing.JLabel _pizzaLabel;
    private javax.swing.JLabel _pizzaMinusLabel;
    private javax.swing.JLabel _pizzaNumberLabel;
    private javax.swing.JPanel _pizzasCard;
    private javax.swing.JLabel _pizzasIconLabel;
    private javax.swing.JLabel _pizzasLabel;
    private javax.swing.JLabel _potatoesAddLabel;
    private javax.swing.JLabel _potatoesLabel;
    private javax.swing.JLabel _potatoesMinusLabel;
    private javax.swing.JLabel _potatoesNumberLabel;
    private javax.swing.JLabel _potatoesTittleLabel;
    private javax.swing.JLabel _previousLabel;
    private javax.swing.JLabel _redBullAddLabel;
    private javax.swing.JLabel _redBullLabel;
    private javax.swing.JLabel _redBullMinusLabel;
    private javax.swing.JLabel _redBullNumberLabel;
    private javax.swing.JLabel _redBullTittleLabel;
    private javax.swing.JLabel _saveLabel;
    private javax.swing.JLabel _saveTittleLabel;
    private javax.swing.JPanel _snacksCard;
    private javax.swing.JLabel _snacksIconLabel;
    private javax.swing.JLabel _snacksLabel;
    private javax.swing.JLabel _sodaAddLabel;
    private javax.swing.JLabel _sodaCardboardLabel;
    private javax.swing.JLabel _sodaLabel;
    private javax.swing.JLabel _sodaMinusLabel;
    private javax.swing.JLabel _sodaNumberLabel;
    private javax.swing.JLabel _sodaTrashLabel;
    private javax.swing.JPanel _startCardPanel;
    private javax.swing.JLabel _startLabel;
    private javax.swing.JLabel _strawberryAddLabel;
    private javax.swing.JLabel _strawberryLabel;
    private javax.swing.JLabel _strawberryMinusLabel;
    private javax.swing.JLabel _strawberryNumberLabel;
    private javax.swing.JLabel _strawberryTittleLabel;
    private javax.swing.JLabel _strippersAddLabel;
    private javax.swing.JLabel _strippersLabel;
    private javax.swing.JLabel _strippersMinusLabel;
    private javax.swing.JLabel _strippersNumberLabel;
    private javax.swing.JLabel _strippersTittleLabel;
    private javax.swing.JLabel _tap1;
    private javax.swing.JLabel _tap2;
    private javax.swing.JLabel _tap3;
    private javax.swing.JLabel _tap4;
    private javax.swing.JLabel _tap5;
    private javax.swing.JPanel _tapCard;
    private javax.swing.JLabel _tickAnchovyLabel;
    private javax.swing.JLabel _tickBaconLabel;
    private javax.swing.JLabel _tickBarbacueLabel;
    private javax.swing.JLabel _tickBeefLabel;
    private javax.swing.JLabel _tickBourbonLabel;
    private javax.swing.JLabel _tickCaramelLabel;
    private javax.swing.JLabel _tickChickenLabel;
    private javax.swing.JLabel _tickCornLabel;
    private javax.swing.JLabel _tickCreamLabel;
    private javax.swing.JLabel _tickFamiliarLabel;
    private javax.swing.JLabel _tickFinizzimaLabel;
    private javax.swing.JLabel _tickHamLabel;
    private javax.swing.JLabel _tickMediumLabel;
    private javax.swing.JLabel _tickMushroomLabel;
    private javax.swing.JLabel _tickOliveLabel;
    private javax.swing.JLabel _tickOnionLabel;
    private javax.swing.JLabel _tickOriginalLabel;
    private javax.swing.JLabel _tickPanLabel;
    private javax.swing.JLabel _tickPepperLabel;
    private javax.swing.JLabel _tickPepperoniLabel;
    private javax.swing.JLabel _tickPineappleLabel;
    private javax.swing.JLabel _tickTomatoLabel;
    private javax.swing.JLabel _tickTomatoeLabel;
    private javax.swing.JLabel _tickTunaLabel;
    private javax.swing.JLabel _tickYorkLabel;
    private javax.swing.JLabel _tittleLabel;
    private javax.swing.JLabel _tomateLabel;
    private javax.swing.JLabel _tomatoLabel;
    private javax.swing.JLabel _tomatoTittleLabel;
    private javax.swing.JLabel _tomatoesLabel;
    private javax.swing.JLabel _trufflesAddLabel;
    private javax.swing.JLabel _trufflesLabel;
    private javax.swing.JLabel _trufflesMinusLabel;
    private javax.swing.JLabel _trufflesNumberLabel;
    private javax.swing.JLabel _trufflesTittleLabel;
    private javax.swing.JLabel _tunaLabel;
    private javax.swing.JLabel _tunasLabel;
    private javax.swing.JLabel _vulcanoAddLabel;
    private javax.swing.JLabel _vulcanoLabel;
    private javax.swing.JLabel _vulcanoMinusLabel;
    private javax.swing.JLabel _vulcanoNumberLabel;
    private javax.swing.JLabel _vulcanoTittleLabel;
    private javax.swing.JLabel _waiterIconLabel;
    private javax.swing.JLabel _waiterLabel;
    private javax.swing.JPanel _waiterPanel;
    private javax.swing.JLabel _waterAddLabel;
    private javax.swing.JLabel _waterLabel;
    private javax.swing.JLabel _waterMinusLabel;
    private javax.swing.JLabel _waterNumberLabel;
    private javax.swing.JLabel _waterTittleLabel;
    private javax.swing.JLabel _wingAddLabel;
    private javax.swing.JLabel _wingLabel;
    private javax.swing.JLabel _wingMinusLabel;
    private javax.swing.JLabel _wingNumberLabel;
    private javax.swing.JLabel _wingTittleLabel;
    private javax.swing.JLabel _wingsAddLabel;
    private javax.swing.JLabel _wingsLabel;
    private javax.swing.JLabel _wingsMinusLabel;
    private javax.swing.JLabel _wingsNumberLabel;
    private javax.swing.JLabel _wingsTittleLabel;
    private javax.swing.JLabel _yorkLabel;
    private javax.swing.JLabel _yorksLabel;
    private javax.swing.JLabel _zeroAddLabel;
    private javax.swing.JLabel _zeroLabel;
    private javax.swing.JLabel _zeroMinusLabel;
    private javax.swing.JLabel _zeroNumberLabel;
    private javax.swing.JLabel _zeroSquirtLabel;
    // End of variables declaration//GEN-END:variables
}
